# Eye Ruler 0.2.17 — Minecraft 1.16.1 / Fabric

**EYE RULER (By Mark + Astra)** provides one wide, full-height measurement
window on the left and the zoomed **LIVE EYE VIEW** at the far-right edge. They
read the **same live tall-resolution render**. The right outline marks the exact
source rectangle shown in the left image. The normal gameplay view and crosshair
remain in their original positions between the panels.

There are only two mod keybindings: **O** for precision sensitivity and **Z** for
the overlay. There is no freeze, screenshot, inspect mode, automatic eye detection,
aim adjustment or extra keybinding. The normal game crosshair remains available.

## Install and use

1. Close Minecraft and replace the previous Eye Ruler JAR in your instance's `mods`
   folder with `eye-ruler-0.2.17.jar`. Keep only one Eye Ruler JAR installed.
2. Use Minecraft **1.16.1**, Fabric Loader **0.15.11 or newer**, Java 8 or newer,
   and Fast/Fancy graphics. This is not a 1.16.5 build. Fabulous and post-processing
   shaders remain unsupported. Fabric API and OBS are not required.
3. Press **Z** in first person to show or hide both live panels.
4. Press **O** to set exact sensitivity `0.012727597`; press it again to restore
   your previous sensitivity. Enable precision before a fresh boat reset and keep
   it constant through the eye measurement. Set the same decimal sensitivity in
   Ninjabrain Bot manually. O does not transmit a sensitivity setting to Ninbot.
5. Bring the eye's reference feature into the clear outline on the right. Read
   its horizontal offset on the left: right is positive, left is negative.
   Apply the correction count with Ninbot's configured adjustment keys. Move
   Ninbot clear of the right eye panel if its window overlaps it.

Both O and Z can be rebound under Controls → Miscellaneous. The former V preview
switch and F8 config-reload bindings have been removed. Restart Minecraft after
editing this mod's config. Z never changes sensitivity.

O retains the previous version's behavior: it changes the live in-memory setting,
which may differ from `options.txt` during precision mode. It restores the old
setting on return to the title screen; a manual sensitivity change cancels the
stored override. Another mod, such as StandardSettings, can still override the
setting. The HUD reports the actual live value.

## New in 0.2.17: twelve per side, smaller inline numbers

- The default ruler now has **12 bands on each side**. Smaller black numbers sit
  inside the colored bands, with **no zero label** and no black label strip below.
- Numbers name the bands counted outward from the centerline. The **outer edge**
  of band N is the exact N-correction mark. The text center is not a measurement
  mark. Left is negative; right is positive. All existing band edges stay aligned
  to the same source-pixel boundaries.
- Both windows, their zoom levels, and the colored band sizes retain the selected
  0.2.16 desktop layout. Label range no longer forces the views to shrink.
- At 3708×2022 with defaults, the left image is **1440×1662** physical pixels,
  with **24 pixels per correction**, a **56-pixel bar height**, and number scale
  **2** (previously 4). The 24-band ruler spans **576 pixels**.
- At 1920×1080, the left image stays **680×900**, with **20 pixels per correction**,
  a **42-pixel bar height**, and number scale **1** (previously 3).
- Very narrow custom layouts limit the displayed range to the available source
  columns. If a band cannot fit a two-digit number even at 1×, labels fall back to
  separate rows below the bar. Calibration and both view sizes take priority.
- Existing default-range configs upgrade automatically from 9 to 12. O/Z,
  sensitivity, F3+C and continuous live rendering retain their existing behavior.

Blue and pink bands have equal widths and top/bottom edges. The zero stroke stays
out of the colored bands. The right edge of its white vertical stroke is zero.
Numbers show magnitudes: left is negative, right is positive. The footer reports
this layout's actual physical pixels per correction.

## Ninjabrain Bot setup

| Setting | Value |
| --- | --- |
| Pixel adjustment type | Tall resolution |
| Resolution height | **16384**, matching `virtualHeight` |
| Boat measurements | Enabled for the boat workflow |
| Boat sensitivity | **0.012727597** when O precision mode is active |
| Crosshair correction | 0 for this mod's custom zero reference |
| Boat reset and correction keys | Your existing Ninbot bindings |

Record a fresh boat reset after changing sensitivity. Keep sensitivity constant
from that reset through the measurement. Use the left ruler for residual pixel
corrections rather than trying to land the mouse exactly on the reference pixel.
The official [boat measurement guide](https://github.com/Ninjabrain1/Ninjabrain-Bot/wiki/Boat-measurements)
explains the reset and correction workflow. Clipboard verification means the F3+C
command was written and read back; it does not confirm Ninbot accepted the throw.

## Configuration and upgrades

The mod reads `config/eye-ruler.json` on launch. Important defaults:

```json
{
  "virtualHeight": 16384,
  "magnification": 12.0,
  "panelWidth": 720,
  "rulerRange": 12,
  "liveViewWidth": 1024,
  "uiScale": 0,
  "schemaVersion": 11
}
```

| Field | Meaning |
| --- | --- |
| `virtualHeight` | Calibration height, 1024–32768. Keep 16384 unless changing Ninbot to match. |
| `magnification` | Base correction spacing from the previous layout, integer 2–64. The new left view enlarges that spacing by up to 2×, fitted like the former bottom ruler. Read the HUD footer for the resulting physical pixels per correction. |
| `panelWidth` | Base image width, 160–1200, fitted to the screen. It controls the right image width; the left image can be up to twice as wide to preserve source coverage at the enlarged ruler scale. |
| `rulerRange` | Display range per side, default 12, capped at 16 and the available source columns. Ranges above 9 keep the established nine-range view sizing. |
| `liveViewWidth` | Shared render width, 256–2048, rounded to a multiple of four. Larger values show more context on the right but make its guide/features smaller and cost more GPU memory. Left calibration is unchanged. |
| `uiScale` | 0 for automatic text sizing; otherwise constrained to fit the screen. |

Schema 11 changes the previous default range 9 to 12 once, without changing
magnification, panel size, live-view width, calibration or other preferences.
Earlier migrations are retained. Custom ranges other than the old defaults are
preserved; schema-11 choices are not migrated again. An intentional old value of
9 cannot be distinguished from the default; reapply it after migration if desired.

`previewZoom`, `previewOverviewZoom`, `panelHeight`, `overviewDivisor`,
`detailSourceThickness`, `detailCrossScale` and `leftRuler` are retained as legacy
config fields but no longer control this layout. There is no V toggle and no fixed
normal-screen zoom multiplier in the right panel.

## Rendering and calibration

For actual source height h and virtual height H, the projection is:

    cropFov = 2 * atan((h / H) * tan(15 degrees))

This keeps the same focal length as a height-H frame at 30° FOV, independently of
buffer width/height and the normal game's FOV. The left image samples the same
centered integer source rectangle as the previous full-height main view. Each
source column is stretched by the final integer correction spacing; each source
row is displayed 1:1. Each color band remains exactly one source column.

The right view reads the same framebuffer with its previous uniform nearest-
neighbor scaling. Its position, source buffer dimensions, view dimensions and guide
size match 0.2.16 with defaults. Keeping those source dimensions independent of the
numbered range prevents an accidental change to either eye view.

| Output resolution | Left source crop / display | Right image | Shared live render |
| --- | --- | --- | --- |
| 1920×1080, defaults | 34×900 at 680×900, 20 px/correction | 408×900 | 1024×2260 |
| 3708×2022, defaults | 60×1662 at 1440×1662, 24 px/correction | 720×1662 | 1024×2364 |

This still performs one additional world-render pass per visible frame. The shared
buffer is wider than 0.2.11's thin buffer; at these sizes its RGBA color and depth
attachments together use roughly 18–19 MiB, excluding driver overhead. It removes
the old separate ordinary-scene copy. Actual FPS and modpack compatibility require
an in-game check; no FPS improvement is claimed.

Both views update on each successfully rendered frame. Hiding the overlay releases
its framebuffer. The extra world pass uses the ordinary frame's camera and tick
interpolation, then restores the original framebuffer, viewport and projection.
Terrain visibility is refreshed for both views. It never freezes the game or
retains a frame for later inspection. The inset includes the scene, not the hand,
HUD, or menus.

As in 0.2.11, visual camera bob, damage shake and nausea distortion are suppressed
while the overlay is active to preserve the measurement ray. Camera input, angles
and option values are unchanged. Measurement still requires a stationary player
and a settled camera.

## Build and source upgrade

Build with JDK 17; production classes target Java 8:

```bash
chmod +x gradlew
./gradlew clean build
```

Install `build/libs/eye-ruler-0.2.17.jar`, not the `-sources.jar`. Build dependencies
come from Gradle, Fabric, Mojang and Maven. No publishing step is involved. See
`VALIDATION.md` for checks and the remaining in-game verification.

The source ZIP has an `eye-ruler/` root. From your **existing source project folder**,
this command extracts it, copies the project files in place, and removes both the
temporary folder and downloaded source ZIP after a successful copy:

```bash
eye_ruler_tmp=$(mktemp -d) && unzip -q "$HOME/Downloads/eye-ruler-0.2.17-source.zip" -d "$eye_ruler_tmp" && cp -a "$eye_ruler_tmp/eye-ruler/." . && rm -r -- "$eye_ruler_tmp" "$HOME/Downloads/eye-ruler-0.2.17-source.zip"
```

Retired `EyeMagnifier`, `HudLayout`, `MouseMixin` and `MeasurementStripLayout`
production source paths contain only package
declarations/comments, so copying this project overwrites their old implementations.
They emit no classes. Use `clean build` to remove obsolete compiled output. Legacy
geometry helpers/tests remain as regressions for old layouts. The old bottom-strip
geometry now lives only in test sources to verify that the chosen ruler sizes
match exactly. The active right view is implemented by `LiveViewLayout`.

No Minecraft game files or Ninbot code are bundled in this project.
