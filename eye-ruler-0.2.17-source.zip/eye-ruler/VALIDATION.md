# Eye Ruler 0.2.17 validation

## Result

`clean build` passed with Gradle 7.6.4, Loom 0.12.56, JDK 17.0.20.1,
Minecraft 1.16.1, Yarn 1.16.1+build.21 and Fabric Loader 0.15.11.
All 13 check groups passed. The release JAR identifies itself as 0.2.17,
contains 26 project classes (all Java 8 class-file version 52), and includes
a nonempty mixin refmap. No Minecraft classes or retired strip implementation
are bundled.

Compared with 0.2.16, the only changed runtime sources are Config, InsetLayout,
RulerOverlay, RulerHud and the version metadata. Sensitivity handling, input
handlers, F3+C, rendering passes, projection and camera mixins are unchanged.

## Ruler and view geometry

The default ruler has 12 bands on each side, numbered 12 down to 1 on the left
and 1 up to 12 on the right. There is no zero label. Small black digits sit
inside the bands, without shadows or a separate black label strip.
The centerline remains zero. A numbered band's outer edge, away from the
centerline, is its exact signed correction boundary. Text centers are labels,
not new measurement positions. All colored bands retain equal widths and
identical top and bottom boundaries, including the two next to zero.

| Default framebuffer | Left image | Band width / height | Font scale | Right image / panel X |
| --- | --- | --- | --- | --- |
| 1920×1080 | 680×900 | 20 / 42 pixels | 1 (was 3) | 408×900 / 1488 |
| 3708×2022 | 1440×1662 | 24 / 56 pixels | 2 (was 4) | 720×1662 / 2940 |

These source/view sizes and band sizes match the 0.2.16 desktop defaults.
The twelve-per-side span is 480 pixels at 1920×1080 and 576 at 3708×2022.
Every two-digit label fits inside its band at those resolutions.

The label range is separated from the established nine-range window-sizing
calculation. Custom displays too narrow for all requested bands cap the range
to the available source columns; they do not enlarge the world render or alter
one-correction spacing just to fit more labels. At very small custom band widths,
labels use rows below the ruler when they cannot fit inside at font scale 1.
There are still only two live panels, with clearance for the normal crosshair.

## Completed checks

| Check | Result |
| --- | --- |
| OppositePanelsCheck | 162 layouts across six framebuffer sizes, three magnifications, three requested ranges (9, 12, 16) and three context widths. Preserved view sizing/source coverage, source render dimensions, right zoom, guide mapping, opposite-edge anchors and center clearance. Every displayed pixel in every signed band maps to the intended source column; every vertical row maps 1:1. Explicit 1920 and 3708 fixtures verify the previous band and window sizes. |
| OverlayCheck | 300 production-painter drawings. Equal complete band rectangles before text, no zero in the active layout, all remaining labels present and ordered, inline black digits within their own bands, exact outer-edge counts, no overlaps/clipping, zero-ray position and fill-before-text ordering. |
| ConfigCheck | Fresh defaults, schema-10 range 9 to schema-11 range 12 migration, persisted reload, explicit schema-11 choices, older migrations and bounds. |
| LiveViewCheck | 150 legacy crop/outline/UV combinations and signed ±16 calibration at three virtual heights. |
| PrecisionSensitivityCheck | Exact sensitivity assignment/restoration, repeated toggles and external slider changes. |
| ProjectionCheck | 64 projection/Ninjabrain pixel-correction cases. |
| RenderPoseCheck | 16 Minecraft matrix-stack/camera isolation regressions. |
| MixinTargetCheck | Required nausea interpolation hook matches intended Minecraft bytecode. |
| MeasurementStripCheck | 288 legacy test-only strip layouts. This is the independent baseline for preferred band sizes, not a shipped third view. |
| RevisionCheck | 25 legacy layout/coverage cases and clipboard diagnostics. |
| ZoomCheck | 432 legacy crop and pixel-mapping cases. |
| MagnifierCheck | 216 legacy magnifier layouts, outside the current render pipeline. |
| PreviewRegionCheck | 2,592 legacy projection/outline cases, outside the current render pipeline. |

Synthetic production-painter previews at 1920×1080 and 3708×2022 were visually
inspected for all 24 labels, equal band sizes, no zero number, the unchanged
window arrangement and crosshair clearance. These are generated test scenes,
not Minecraft screenshots.

## Remaining in-game verification

No graphical Minecraft session was run here. Automated geometry and build checks
do not establish modpack compatibility, actual OpenGL output, FPS or stronghold
hit accuracy.

1. Close Minecraft and replace the previous Eye Ruler JAR, keeping one installed.
2. Press Z. Confirm the 0.2.17 version, 12 small labels per side, no zero number,
   the same band sizes and the same two window sizes/zoom levels.
3. Confirm both panels update live and the right outline maps the left crop.
4. Use the existing boat-reset/F3+C workflow in a practice world, with matching
   Ninbot height and sensitivity. Count signed corrections at the band edges.
5. Confirm O toggles/restores precision sensitivity and Z toggles both views.

Defaults migrate automatically; no config deletion or Ninbot setting change is
required for this release.
