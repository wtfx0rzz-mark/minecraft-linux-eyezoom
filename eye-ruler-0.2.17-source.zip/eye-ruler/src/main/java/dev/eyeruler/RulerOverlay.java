package dev.eyeruler;

/** Shared by the Minecraft HUD and the headless drawing regression test. */
public final class RulerOverlay {
    public static final int BLUE = 0xff55c8ef, PINK = 0xffee8dbd;
    public static final int WHITE = 0xffeeeeee, BLACK = 0xff000000, BACKGROUND = 0xff111720;
    public interface Canvas {
        void fill(int x, int y, int width, int height, int color);
        int textWidth(String text);
        void text(String text, int x, int y, int scale, int color);
    }
    private RulerOverlay() {}

    public static void draw(InsetLayout l, Canvas c) {
        draw(new Geometry(l), c);
    }

    /** Shared pixel geometry for the original ruler and its enlarged live strip. */
    public static final class Geometry {
        public final int scale, y, height, centerX, panelX, panelWidth, zeroLineBottom;
        public final int range, step, barY, barHeight, rulerLabelScale, labelY, labelRows;
        public final boolean compactLabels, labelsInside;
        public Geometry(InsetLayout l) {
            this(l.scale, l.y, l.height, l.centerX(), l.panelX, l.panelWidth,
                l.range, l.step, l.barY, l.barHeight, l.rulerLabelScale, l.labelY, l.labelRows,
                l.y + l.height, l.compactLabels, l.labelsInside);
        }
        public Geometry(int scale, int y, int height, int centerX, int panelX, int panelWidth,
                        int range, int step, int barY, int barHeight, int labelScale,
                        int labelY, int labelRows) {
            this(scale, y, height, centerX, panelX, panelWidth, range, step, barY, barHeight,
                labelScale, labelY, labelRows, y + height);
        }
        public Geometry(int scale, int y, int height, int centerX, int panelX, int panelWidth,
                        int range, int step, int barY, int barHeight, int labelScale,
                        int labelY, int labelRows, int zeroLineBottom) {
            this(scale, y, height, centerX, panelX, panelWidth, range, step, barY, barHeight,
                labelScale, labelY, labelRows, zeroLineBottom, false, false);
        }
        private Geometry(int scale, int y, int height, int centerX, int panelX, int panelWidth,
                        int range, int step, int barY, int barHeight, int labelScale,
                        int labelY, int labelRows, int zeroLineBottom, boolean compactLabels,
                        boolean labelsInside) {
            this.scale=scale; this.y=y; this.height=height; this.centerX=centerX;
            this.panelX=panelX; this.panelWidth=panelWidth; this.range=range; this.step=step;
            this.barY=barY; this.barHeight=barHeight; this.rulerLabelScale=labelScale;
            this.labelY=labelY; this.labelRows=labelRows;
            this.zeroLineBottom=zeroLineBottom;
            this.compactLabels=compactLabels; this.labelsInside=labelsInside;
        }
        public int centerX() { return centerX; }
        public int rulerX(int offset) { return centerX + offset * step; }
    }

    public static void draw(Geometry l, Canvas c) {
        int barLeft = l.rulerX(-l.range);
        int barWidth = 2 * l.range * l.step;
        // One continuous base gives both colors identical, borderless cutoffs.
        c.fill(barLeft, l.barY, barWidth, l.barHeight, PINK);
        for (int i = -l.range; i < l.range; i++) {
            if ((i & 1) == 0) c.fill(l.rulerX(i), l.barY, l.step, l.barHeight, BLUE);
        }
        // Preserve the zero ray, but leave EVERY colored band fully visible.
        // The RIGHT edge of the stroke above/below the bar is still zero.
        int stroke = Math.max(1, l.scale / 2);
        int afterBar = l.barY + l.barHeight;
        for (int part = 0; part < 2; part++) {
            int y = part == 0 ? l.y : afterBar;
            int height = part == 0 ? l.barY - l.y : Math.max(0, l.zeroLineBottom - afterBar);
            c.fill(l.centerX() - 2 * stroke, y, stroke, height, 0xff000000);
            c.fill(l.centerX() - stroke, y, stroke, height, WHITE);
        }

        if (l.labelsInside) {
            // Labels name the bands counted outward from zero. The band's OUTER
            // edge is the exact signed correction boundary, not the text center.
            for (int band = -l.range; band < l.range; band++) {
                int magnitude = band < 0 ? -band : band + 1;
                String text = Integer.toString(magnitude);
                int textWidth = c.textWidth(text) * l.rulerLabelScale;
                c.text(text, l.rulerX(band) + (l.step - textWidth) / 2,
                    l.labelY, l.rulerLabelScale, BLACK);
            }
            return;
        }

        int pad = 3 * Integer.toString(l.range).length() * l.rulerLabelScale;
        int left = Math.max(l.panelX, l.rulerX(-l.range) - pad);
        int right = Math.min(l.panelX + l.panelWidth, l.rulerX(l.range) + pad);
        c.fill(left, l.labelY - l.rulerLabelScale, right - left,
            (10 * l.labelRows + 2) * l.rulerLabelScale, BACKGROUND);
        // All fills precede ALL labels: later bands must never erase a digit.
        // Magnitudes keep digits large; the HUD explicitly gives left - / right +.
        for (int i = -l.range; i <= l.range; i++) {
            if (l.compactLabels && i == 0) continue;
            String text = Integer.toString(Math.abs(i));
            int textWidth = c.textWidth(text) * l.rulerLabelScale;
            // End labels may use the panel's padding when the preview fits the ruler.
            int x = Math.max(l.panelX, Math.min(l.panelX + l.panelWidth - textWidth,
                l.rulerX(i) - textWidth / 2));
            int row = Math.floorMod(i, l.labelRows);
            c.text(text, x, l.labelY + row * 10 * l.rulerLabelScale, l.rulerLabelScale, WHITE);
        }
    }
}
