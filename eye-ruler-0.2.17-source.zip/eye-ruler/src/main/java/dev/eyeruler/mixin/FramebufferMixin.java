package dev.eyeruler.mixin;

import dev.eyeruler.EyeRuler;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Framebuffer.class)
public abstract class FramebufferMixin {
    // Outline passes change the viewport. Every return to our target must restore its dimensions.
    @ModifyVariable(method = "beginWrite", at = @At("HEAD"), argsOnly = true)
    private boolean eyeRulerViewport(boolean setViewport) {
        return setViewport || (EyeRuler.rendering && (Object) this == EyeRuler.target);
    }
}
