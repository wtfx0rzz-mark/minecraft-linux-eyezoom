package dev.eyeruler.mixin;

import dev.eyeruler.EyeRuler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void eyeRulerTick(CallbackInfo ci) { EyeRuler.tick(); }
    @Inject(method = "getFramebuffer", at = @At("HEAD"), cancellable = true)
    private void eyeRulerTarget(CallbackInfoReturnable<Framebuffer> cir) {
        if (EyeRuler.rendering) cir.setReturnValue(EyeRuler.target);
    }
}
