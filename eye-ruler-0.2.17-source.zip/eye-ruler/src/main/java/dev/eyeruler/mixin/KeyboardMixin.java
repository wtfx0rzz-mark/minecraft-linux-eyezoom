package dev.eyeruler.mixin;

import dev.eyeruler.CopyStatus;
import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public abstract class KeyboardMixin {
    @Shadow public abstract String getClipboard();
    @Inject(method = "setClipboard", at = @At("RETURN"))
    private void eyeRulerObserveCopy(String value, CallbackInfo ci) {
        if (!CopyStatus.isMeasurement(value)) return;
        boolean verified = false;
        try { verified = value.equals(getClipboard()); } catch (RuntimeException ignored) {}
        CopyStatus.record(value, verified);
    }
}
