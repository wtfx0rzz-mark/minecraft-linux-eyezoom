package dev.eyeruler.mixin;

import dev.eyeruler.EyeRuler;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    // These visual offsets otherwise move the main crosshair away from the copied yaw/pitch ray.
    @Inject(method = {"bobView", "bobViewWhenHurt"}, at = @At("HEAD"), cancellable = true)
    private void eyeRulerStableRay(MatrixStack matrices, float delta, CallbackInfo ci) {
        if (EyeRuler.active()) ci.cancel();
    }
    // 1.16.1: ordinal 0 interpolates lastNauseaStrength / nextNauseaStrength.
    @Redirect(method = "renderWorld", require = 1, allow = 1, at = @At(value = "INVOKE",
        target = "Lnet/minecraft/util/math/MathHelper;lerp(FFF)F", ordinal = 0))
    private float eyeRulerPortalDistortion(float delta, float from, float to) {
        return EyeRuler.active() ? 0 : MathHelper.lerp(delta, from, to);
    }
    @Redirect(method = "renderWorld", at = @At(value = "INVOKE", target =
        "Lnet/minecraft/client/render/WorldRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;FJZLnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/GameRenderer;Lnet/minecraft/client/render/LightmapTextureManager;Lnet/minecraft/util/math/Matrix4f;)V"))
    private void eyeRulerScenes(WorldRenderer world, MatrixStack matrices, float delta, long limit,
                                boolean outline, Camera camera, GameRenderer renderer,
                                LightmapTextureManager lightmap, Matrix4f projection) {
        EyeRuler.renderInset(world, matrices, delta, limit, camera, renderer, lightmap, projection);
        world.render(matrices, delta, limit, outline, camera, renderer, lightmap, projection);
    }
}
