package dev.eyeruler.mixin;

// Intentionally no class: copying this source update over 0.1.2 removes its old mouse hook.
