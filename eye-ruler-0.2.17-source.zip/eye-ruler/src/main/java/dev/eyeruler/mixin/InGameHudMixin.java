package dev.eyeruler.mixin;

import dev.eyeruler.EyeRuler;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void eyeRulerHud(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        EyeRuler.drawHud(matrices);
    }
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void eyeRulerCrosshair(MatrixStack matrices, CallbackInfo ci) {
        if (EyeRuler.hasInset()) ci.cancel();
    }
}
