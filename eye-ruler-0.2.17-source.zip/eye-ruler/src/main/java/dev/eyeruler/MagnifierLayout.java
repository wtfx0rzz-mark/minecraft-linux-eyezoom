package dev.eyeruler;

/** A centered, uniformly magnified crop of the ordinary scene, in physical pixels. */
public final class MagnifierLayout {
    public final int zoom;
    public final int panelX, x, y, width, height;
    public final int copyX, copyY, sourceWidth, sourceHeight;
    public final double sampleX, sampleY, sampleWidth, sampleHeight;

    public MagnifierLayout(InsetLayout ruler, int screenWidth, int screenHeight, int zoom) {
        if (zoom < 2 || zoom > 28) throw new IllegalArgumentException("Preview zoom must be 2 through 28");
        this.zoom = zoom;
        panelX = ruler.panelX + ruler.panelWidth;
        x = panelX + ruler.margin;
        y = ruler.y;
        width = ruler.width;
        height = ruler.height;
        sampleWidth = width / (double) zoom;
        sampleHeight = height / (double) zoom;
        // Padding allows an exact fractional crop even for odd window sizes.
        sourceWidth = 2 * (int) Math.ceil(sampleWidth / 2 + 1);
        sourceHeight = 2 * (int) Math.ceil(sampleHeight / 2 + 1);
        copyX = (screenWidth - sourceWidth) / 2;
        copyY = (screenHeight - sourceHeight) / 2;
        sampleX = screenWidth / 2.0 - copyX - sampleWidth / 2;
        sampleY = screenHeight / 2.0 - copyY - sampleHeight / 2;
    }
    public double centerX() { return x + width / 2.0; }
    public double centerY() { return y + height / 2.0; }
}
