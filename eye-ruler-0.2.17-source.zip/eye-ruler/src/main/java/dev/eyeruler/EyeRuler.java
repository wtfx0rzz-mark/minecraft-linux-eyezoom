package dev.eyeruler;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.options.KeyBinding;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.Matrix4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;
import java.util.Arrays;

public final class EyeRuler implements ClientModInitializer {
    public static Config config;
    public static Framebuffer target;
    public static boolean rendering;
    public static InsetLayout layout;
    public static LiveViewLayout liveView;
    private static boolean frameReady;
    private static boolean enabled;
    private static KeyBinding toggle;
    private static KeyBinding precisionKey;
    public static final PrecisionSensitivity precision = new PrecisionSensitivity();

    @Override public void onInitializeClient() {
        config = Config.load();
    }
    private static void registerKeys(MinecraftClient client) {
        toggle = new KeyBinding("key.eye_ruler.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "key.categories.misc");
        precisionKey = new KeyBinding("key.eye_ruler.precision", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "key.categories.misc");
        int n = client.options.keysAll.length;
        ((dev.eyeruler.mixin.GameOptionsAccessor) client.options).eyeRulerSetKeys(Arrays.copyOf(client.options.keysAll, n + 2));
        client.options.keysAll[n] = toggle;
        client.options.keysAll[n + 1] = precisionKey;
        client.options.load();
    }
    public static void tick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (toggle == null) registerKeys(client);
        precision.sync(client.options.mouseSensitivity);
        while (precisionKey.wasPressed()) {
            if (client.world != null && client.player != null && client.currentScreen == null) {
                client.options.mouseSensitivity = precision.toggle(client.options.mouseSensitivity);
                if (!precision.isActive()) client.options.write();
                client.player.sendMessage(new LiteralText(precision.isActive()
                    ? "Eye Ruler: precision sensitivity 0.012727597. Record a fresh boat reset before measuring."
                    : "Eye Ruler: restored sensitivity " + client.options.mouseSensitivity), true);
            }
        }
        if (client.world == null && precision.isActive()) {
            client.options.mouseSensitivity = precision.restore(client.options.mouseSensitivity);
            client.options.write();
        }
        while (toggle.wasPressed()) {
            if (client.world != null && client.currentScreen == null) {
                enabled = !enabled;
                if (enabled && client.options.perspective != 0) {
                    enabled = false;
                    client.player.sendMessage(new LiteralText("Eye Ruler: switch to first person first."), true);
                }
            }
        }
        if (enabled && (client.options.graphicsMode == net.minecraft.client.options.GraphicsMode.FABULOUS || client.gameRenderer.getShader() != null)) {
            enabled = false;
            if (client.player != null) client.player.sendMessage(new LiteralText("Eye Ruler: use Fast/Fancy graphics and disable post-processing shaders."), true);
        }
        if (client.world == null || client.options.perspective != 0) enabled = false;
        if (!enabled && target != null && !rendering) { target.delete(); target = null; frameReady = false; }
    }
    public static boolean active() {
        MinecraftClient c = MinecraftClient.getInstance();
        return enabled && c.world != null && c.player != null && c.options.perspective == 0;
    }
    /** Runs before the ordinary scene, using that frame's camera and interpolation. */
    public static void renderInset(WorldRenderer world, MatrixStack matrices, float delta, long limit,
                                   Camera camera, GameRenderer renderer, LightmapTextureManager lightmap,
                                   Matrix4f normalProjection) {
        frameReady = false;
        liveView = null;
        if (!active()) return;
        MinecraftClient c = MinecraftClient.getInstance();
        layout = new InsetLayout(c.getWindow().getFramebufferWidth(), c.getWindow().getFramebufferHeight(),
            config.uiScale, config.panelWidth, config.panelHeight, config.overviewDivisor,
            config.magnification, config.rulerRange, config.leftRuler,
            config.detailSourceThickness, config.detailCrossScale, true);
        if (!layout.visible || c.options.graphicsMode == net.minecraft.client.options.GraphicsMode.FABULOUS
            || renderer.getShader() != null) return;
        liveView = new LiveViewLayout(layout, config.liveViewWidth);
        Framebuffer original = c.getFramebuffer();
        boolean scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
        MatrixStack insetMatrices = RenderPose.copyRoot(matrices);
        try {
            GL11.glDisable(GL11.GL_SCISSOR_TEST);
            if (target == null || target.textureWidth != liveView.sourceWidth || target.textureHeight != liveView.sourceHeight) {
                if (target != null) target.delete();
                target = new Framebuffer(liveView.sourceWidth, liveView.sourceHeight, true, MinecraftClient.IS_SYSTEM_MAC);
                target.setTexFilter(GL11.GL_NEAREST);
            }
            rendering = true;
            target.beginWrite(true);
            Matrix4f projection = Matrix4f.viewboxMatrix(Projection.fov(liveView.sourceHeight, config.virtualHeight),
                (float) liveView.sourceWidth / liveView.sourceHeight, 0.05f, renderer.getViewDistance() * 4.0f);
            renderer.loadProjectionMatrix(projection);
            // The two FOVs need separate visibility passes, even with a stationary camera.
            world.scheduleTerrainUpdate();
            world.render(insetMatrices, delta, limit, false, camera, renderer, lightmap, projection);
            frameReady = true;
        } finally {
            rendering = false;
            original.beginWrite(true);
            renderer.loadProjectionMatrix(normalProjection);
            world.scheduleTerrainUpdate();
            if (scissor) GL11.glEnable(GL11.GL_SCISSOR_TEST);
        }
    }
    public static void drawHud(MatrixStack s) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (active() && frameReady && layout != null && liveView != null && target != null
            && liveView.sourceWidth == target.textureWidth && liveView.sourceHeight == target.textureHeight) {
            RulerHud.draw(s, c.getWindow().getFramebufferWidth(), c.getWindow().getFramebufferHeight(), layout);
        }
    }
    public static boolean hasInset() { return active() && frameReady; }
}
