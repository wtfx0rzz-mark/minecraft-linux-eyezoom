package dev.eyeruler;

/** Remembers the user's sensitivity without overriding later manual changes. */
public final class PrecisionSensitivity {
    public static final double TARGET = 0.012727597;
    private boolean active;
    private double previous;

    public boolean isActive() { return active; }
    public void sync(double current) {
        if (active && Double.compare(current, TARGET) != 0) active = false;
    }
    public double toggle(double current) {
        sync(current);
        if (active) return restore(current);
        previous = current;
        active = true;
        return TARGET;
    }
    public double restore(double current) {
        sync(current);
        if (!active) return current;
        active = false;
        return previous;
    }
}
