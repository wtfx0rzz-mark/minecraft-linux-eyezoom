package dev.eyeruler;

/** All geometry is in physical framebuffer pixels, independent of Minecraft GUI scale. */
public final class InsetLayout {
    public final int scale, margin, sideWidth, x, y, width, height, sourceWidth, sourceHeight;
    public final int panelX, panelY, panelWidth, panelHeight, step, range, stripX, stripY, stripWidth;
    public final int stripHeight, barY, labelStep, divisor;
    public final int detailSourceThickness, detailCrossScale, detailDisplayWidth, centerSafetyGap;
    public final int verticalX, verticalBarX, rulerLabelScale, barHeight, rotatedCrossScale;
    public final int sampleX, sampleY, sampleWidth, labelY, labelRows;
    public final int contextPanelX, contextPanelWidth, contextWidth;
    public final boolean visible, compactLabels, labelsInside;

    public InsetLayout(int screenWidth, int screenHeight, int requestedScale, int wantedWidth,
                       int wantedHeight, int overviewDivisor, double magnification,
                       int wantedRange, boolean leftRuler, int sourceThickness, int crossScale) {
        this(screenWidth, screenHeight, requestedScale, wantedWidth, wantedHeight, overviewDivisor,
            magnification, wantedRange, leftRuler, sourceThickness, crossScale, false);
    }

    public InsetLayout(int screenWidth, int screenHeight, int requestedScale, int wantedWidth,
                       int wantedHeight, int overviewDivisor, double magnification,
                       int wantedRange, boolean leftRuler, int sourceThickness, int crossScale,
                       boolean oppositeSides) {
        int auto = Math.max(screenHeight >= 720 ? 2 : 1, Math.round(screenHeight / 540f));
        scale = Math.max(1, Math.min(requestedScale == 0 ? auto : requestedScale,
            Math.max(1, Math.min(4, Math.min(screenWidth / 640, screenHeight / 300)))));
        margin = 6 * scale;
        centerSafetyGap = 48 * scale;
        int requestedRange = Math.max(1, Math.min(16, wantedRange));
        // Additional labels must not resize either view or change its pixel scale.
        int sizingRange = oppositeSides ? Math.min(9, requestedRange) : requestedRange;
        // Derive the original eye coverage and context size before enlarging the ruler.
        int availableWidth = Math.max(16,
            Math.min(wantedWidth, (screenWidth / 2 - centerSafetyGap) / 2 - 2 * margin)) & ~1;
        int requestedStep = (int) ZoomGeometry.normalize(magnification);
        int baseStep = Math.max(2, Math.min(requestedStep, availableWidth / (2 * sizingRange)));
        // The ruler measures the central signed range. Extra columns provide context,
        // without changing the number of display pixels in a correction band.
        sampleWidth = Math.max(2 * sizingRange, (availableWidth / baseStep) & ~1);
        range = Math.min(requestedRange, sampleWidth / 2);
        contextWidth = sampleWidth * baseStep;
        // Match 0.2.15's larger bottom ruler, including its integer fit on smaller screens.
        // The main view gets wider by the same ratio, preserving every source column.
        step = oppositeSides ? Math.max(baseStep,
            Math.min(2 * baseStep, contextWidth / (2 * sizingRange + 2))) : baseStep;
        width = sampleWidth * step;
        int header = 48 * scale;
        int footer = 42 * scale;
        panelX = 0;
        panelY = 0;
        panelWidth = width + 2 * margin;
        contextPanelWidth = contextWidth + 2 * margin;
        contextPanelX = oppositeSides ? screenWidth - contextPanelWidth : panelX + panelWidth;
        panelHeight = screenHeight;
        x = panelX + margin;
        y = header;
        height = Math.max(16, screenHeight - header - footer) & ~1;
        // One rendered row per displayed row. Only X is stretched. Padding keeps
        // both buffer and crop centers on integer pixel boundaries.
        divisor = 1;
        sourceWidth = (sampleWidth + 3) & ~3;
        sourceHeight = (height + 3) & ~3;
        sampleX = (sourceWidth - sampleWidth) / 2;
        sampleY = (sourceHeight - height) / 2;
        stripX = x;
        stripY = y;
        stripWidth = width;
        stripHeight = height;
        int previousLabelScale = oppositeSides && step > baseStep
            ? Math.max(1, Math.min(4, step / (6 * Integer.toString(sizingRange).length())))
            : (sizingRange > 8 && step >= 8 ? Math.min(2, scale)
                : Math.max(1, Math.min(4, step / 8)));
        compactLabels = oppositeSides;
        rulerLabelScale = compactLabels
            ? Math.max(1, Math.min(2, step / (6 * Integer.toString(range).length())))
            : previousLabelScale;
        // Keep the selected bar height independent of the smaller font.
        barHeight = oppositeSides ? Math.max(14 * scale, 14 * previousLabelScale) : 14 * scale;
        barY = centerY() - barHeight / 2;
        int labelSpace = 6 * Integer.toString(range).length() * rulerLabelScale;
        labelsInside = compactLabels && labelSpace <= step;
        labelY = labelsInside ? barY + (barHeight - 8 * rulerLabelScale) / 2
            : barY + barHeight + 2 * rulerLabelScale;
        labelRows = Math.max(1, (labelSpace + step - 1) / step);
        labelStep = 1;
        sideWidth = 0;
        detailSourceThickness = Math.max(2, Math.min(64, sourceThickness)) & ~1;
        detailCrossScale = Math.max(1, Math.min(6, crossScale));
        detailDisplayWidth = width;
        rotatedCrossScale = 0;
        verticalX = x;
        verticalBarX = x;
        visible = screenWidth >= 320 && screenHeight >= 280 && width >= 16
            && (oppositeSides
                ? panelX + panelWidth <= screenWidth / 2 - centerSafetyGap
                    && contextPanelX >= screenWidth / 2 + centerSafetyGap
                : panelX + 2 * panelWidth <= screenWidth / 2 - centerSafetyGap);
    }
    public int centerX() { return x + width / 2; }
    public int centerY() { return y + height / 2; }
    public int rulerX(int offset) { return centerX() + offset * step; }
    public int verticalRange() { return 0; }
    public int rulerY(int offset) { return centerY(); }
    public int verticalTop() { return y; }
}
