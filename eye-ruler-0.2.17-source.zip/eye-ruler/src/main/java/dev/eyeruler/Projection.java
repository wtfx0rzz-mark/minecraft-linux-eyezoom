package dev.eyeruler;

public final class Projection {
    private Projection() {}
    public static double fov(int cropHeight, int virtualHeight) {
        return Math.toDegrees(2.0 * Math.atan(cropHeight * Math.tan(Math.toRadians(15.0)) / virtualHeight));
    }
    public static double correction(int virtualHeight, double pitch) {
        return Math.toDegrees(Math.atan(2.0 * Math.tan(Math.toRadians(15.0)) / virtualHeight)) / Math.cos(Math.toRadians(pitch));
    }
}
