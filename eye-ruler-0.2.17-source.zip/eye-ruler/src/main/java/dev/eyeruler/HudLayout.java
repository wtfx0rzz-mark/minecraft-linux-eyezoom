package dev.eyeruler;

// Intentionally no class: source-overlay upgrades replace the obsolete full-screen HUD layout.
