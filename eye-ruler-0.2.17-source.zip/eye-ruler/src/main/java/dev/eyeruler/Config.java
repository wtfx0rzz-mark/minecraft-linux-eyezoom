package dev.eyeruler;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    public int virtualHeight = 16384;
    public double magnification = 12;
    public int panelWidth = 720;
    public int panelHeight = 650;
    public int overviewDivisor = 3;
    public int detailSourceThickness = 32;
    public int detailCrossScale = 3;
    public int previewZoom = 14;
    public int previewOverviewZoom = 7;
    public int schemaVersion = 0;
    public int rulerRange = 12;
    public int liveViewWidth = 1024;
    public boolean leftRuler = true;
    public int uiScale = 0; // 0 = automatic, independent of world magnification
    public static Config load() {
        return load(FabricLoader.getInstance().getConfigDir().resolve("eye-ruler.json"));
    }
    static Config load(Path path) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Config config = new Config();
        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                Config loaded = gson.fromJson(reader, Config.class);
                if (loaded != null) config = loaded;
            } catch (Exception e) { System.err.println("[Eye Ruler] Invalid config; using defaults: " + e); }
        }
        boolean migrate = config.schemaVersion < 11;
        config.normalize();
        if (!Files.exists(path) || migrate) {
            try { Files.createDirectories(path.getParent());
                try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) { gson.toJson(config, writer); }
            } catch (Exception e) { System.err.println("[Eye Ruler] Could not save config: " + e); }
        }
        return config;
    }
    private void normalize() {
        if (schemaVersion < 3) {
            if (magnification == 3.5) magnification = 4;
            if (rulerRange == 24) rulerRange = 60;
        }
        if (schemaVersion < 4) {
            if (magnification == 4) magnification = 5;
            if (panelWidth == 480) panelWidth = 600;
            if (panelHeight == 560) panelHeight = 650;
            if (overviewDivisor == 4) overviewDivisor = 3;
        }
        if (schemaVersion < 5) {
            if (magnification == 5) magnification = 32;
            if (rulerRange == 60) rulerRange = 8;
        }
        if (schemaVersion < 6 && magnification == 32) magnification = 24;
        if (schemaVersion < 7 && panelWidth == 600) panelWidth = 720;
        if (schemaVersion < 9) {
            if (magnification == 24) magnification = 12;
            if (rulerRange == 8) rulerRange = 16;
        }
        if (schemaVersion < 10 && rulerRange == 16) rulerRange = 9;
        if (schemaVersion < 11 && rulerRange == 9) rulerRange = 12;
        liveViewWidth = (Math.max(256, Math.min(2048, liveViewWidth)) + 3) & ~3;
        uiScale = Math.max(0, Math.min(6, uiScale));
        virtualHeight = Math.max(1024, Math.min(32768, virtualHeight));
        magnification = ZoomGeometry.normalize(magnification);
        schemaVersion = Math.max(11, schemaVersion);
        previewZoom = Math.max(2, Math.min(28, previewZoom));
        previewOverviewZoom = Math.max(2, Math.min(28, previewOverviewZoom));
        rulerRange = Math.max(4, Math.min(200, rulerRange));
        panelWidth = Math.max(160, Math.min(1200, panelWidth));
        panelHeight = Math.max(160, Math.min(1600, panelHeight));
        overviewDivisor = Math.max(1, Math.min(4, overviewDivisor));
        detailSourceThickness = Math.max(2, Math.min(64, detailSourceThickness)) & ~1;
        detailCrossScale = Math.max(1, Math.min(6, detailCrossScale));
    }
}
