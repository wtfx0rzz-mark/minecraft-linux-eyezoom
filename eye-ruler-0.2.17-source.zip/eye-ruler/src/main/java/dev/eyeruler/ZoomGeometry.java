package dev.eyeruler;

public final class ZoomGeometry {
    private ZoomGeometry() {}
    public static double normalize(double value) {
        return Double.isFinite(value) ? Math.max(2, Math.min(64, Math.round(value))) : 12;
    }
    public static int sourceSize(int screen, double scale) {
        return Math.max(4, ((int) (screen / scale)) & ~3);
    }
    public static int displaySize(int source, double scale) { return (int) Math.round(source * scale); }
    public static int boundary(int center, int pixelOffset, double scale) {
        return (int) Math.ceil(center + pixelOffset * scale - 0.5);
    }
}
