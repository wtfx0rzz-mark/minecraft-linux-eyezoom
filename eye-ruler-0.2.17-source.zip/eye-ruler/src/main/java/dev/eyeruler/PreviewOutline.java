package dev.eyeruler;

/** Paints outside the sampled region, with no fill over its interior. */
public final class PreviewOutline {
    public interface Canvas {
        void fill(double left, double top, double right, double bottom, int color);
    }
    private PreviewOutline() {}

    public static void draw(PreviewRegion.Bounds area, MagnifierLayout view, Canvas canvas) {
        ring(area, view, canvas, 2, 0xff000000);
        ring(area, view, canvas, 1, 0xffeeeeee);
    }

    private static void ring(PreviewRegion.Bounds a, MagnifierLayout v, Canvas c, int t, int color) {
        fill(v, c, a.left-t, a.top-t, a.right+t, a.top, color);
        fill(v, c, a.left-t, a.bottom, a.right+t, a.bottom+t, color);
        fill(v, c, a.left-t, a.top, a.left, a.bottom, color);
        fill(v, c, a.right, a.top, a.right+t, a.bottom, color);
    }

    private static void fill(MagnifierLayout v, Canvas c, double x0, double y0,
                             double x1, double y1, int color) {
        // Clip individual strokes; clamping the bounds would invent false crop edges.
        x0 = Math.max(v.x, x0); y0 = Math.max(v.y, y0);
        x1 = Math.min(v.x + v.width, x1); y1 = Math.min(v.y + v.height, y1);
        if (x1 > x0 && y1 > y0) c.fill(x0, y0, x1, y1, color);
    }
}
