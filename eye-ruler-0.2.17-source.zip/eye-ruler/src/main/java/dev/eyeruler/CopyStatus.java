package dev.eyeruler;

/** Observes Minecraft's own F3+C writes. Never changes or polls unrelated clipboard data. */
public final class CopyStatus {
    public static String summary = "F3+C: no copy observed yet";
    public static String compactSummary = "F3+C: no copy observed yet";
    public static String coordinates = "F3+C copies X/Z and angle";
    public static String angles = "Readback confirms clipboard only";
    public static String details = "";
    public static String hint = "Ninbot must be unlocked; blue boat records the reset first.";
    private static String lastPayload;
    private static int copyCount;
    private CopyStatus() {}

    public static boolean isMeasurement(String value) {
        if (value == null || !value.startsWith("/execute in ")) return false;
        String[] p = value.split(" ");
        if (p.length != 11 || !"run".equals(p[3]) || !"tp".equals(p[4]) || !"@s".equals(p[5])) return false;
        try {
            for (int i = 6; i < 11; i++) if (!Double.isFinite(Double.parseDouble(p[i]))) return false;
            return true;
        } catch (NumberFormatException ex) { return false; }
    }
    public static void record(String payload, boolean verified) {
        if (!isMeasurement(payload)) return;
        String[] p = payload.split(" ");
        boolean duplicate = payload.equals(lastPayload);
        lastPayload = payload;
        copyCount++;
        compactSummary = "F3+C #" + copyCount + (verified ? ": clipboard verified" : ": readback failed");
        coordinates = "X " + p[6] + "  Z " + p[8];
        angles = "Yaw " + p[9] + "  Pitch " + p[10];
        summary = "F3+C #" + copyCount + (verified ? ": clipboard verified; Ninbot acceptance unknown" : ": copy attempted; clipboard verification failed");
        details = "Copied X " + p[6] + "  Z " + p[8] + "  Yaw " + p[9] + "  Pitch " + p[10];
        if (duplicate) hint = "Same reading copied again: Ninbot may ignore duplicates.";
        else if (!"minecraft:overworld".equals(p[2])) hint = "Outside Overworld: Ninbot will not add a normal eye throw.";
        else if (Double.parseDouble(p[10]) > 0) hint = "Looking down: Ninbot skips eye throws with positive pitch.";
        else hint = "No row? Check blue boat, calculator lock, AA mode and clipboard reader.";
    }
}
