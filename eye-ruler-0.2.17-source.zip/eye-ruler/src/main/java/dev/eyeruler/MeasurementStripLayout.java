package dev.eyeruler;

// Retired in 0.2.16. Kept as an overwrite stub for in-place source upgrades.
// The old strip geometry exists only in tests to verify matching ruler sizes.
