package dev.eyeruler;

/** One live tall-resolution texture, shared by the ruler and its context view. */
public final class LiveViewLayout {
    public interface Canvas { void fill(double x0, double y0, double x1, double y1, int color); }
    public final int sourceWidth, sourceHeight, sampleX, sampleY;
    public final int panelX, panelWidth, x, y, width, height;
    public final double viewX, viewY, viewWidth, viewHeight, displayScale;
    public final double guideLeft, guideTop, guideRight, guideBottom;

    public LiveViewLayout(InsetLayout ruler, int requestedWidth) {
        sourceWidth = round4(Math.max(ruler.sourceWidth, Math.max(256, Math.min(2048, requestedWidth))));
        sourceHeight = round4(Math.max(ruler.sourceHeight,
            Math.min(4096, (int) Math.ceil((double) sourceWidth * ruler.height / ruler.contextWidth))));
        sampleX = (sourceWidth - ruler.sampleWidth) / 2;
        sampleY = (sourceHeight - ruler.height) / 2;
        panelX = ruler.contextPanelX;
        panelWidth = ruler.contextPanelWidth;
        x = panelX + ruler.margin;
        y = ruler.y;
        width = ruler.contextWidth;
        height = ruler.height;
        displayScale = Math.min((double) width / sourceWidth, (double) height / sourceHeight);
        viewWidth = sourceWidth * displayScale;
        viewHeight = sourceHeight * displayScale;
        viewX = x + (width - viewWidth) / 2;
        viewY = y + (height - viewHeight) / 2;
        guideLeft = mapX(sampleX);
        guideTop = mapY(sampleY);
        guideRight = mapX(sampleX + ruler.sampleWidth);
        guideBottom = mapY(sampleY + ruler.height);
    }

    public double mapX(double sourceX) { return viewX + sourceX * displayScale; }
    public double mapY(double sourceY) { return viewY + sourceY * displayScale; }
    private static int round4(int value) { return (value + 3) & ~3; }

    /** Strokes lie outside the exact sample edges, leaving its interior clear. */
    public void drawOutline(Canvas canvas) {
        drawOutline(canvas, guideBottom);
    }
    /** Crop the guide's bottom when the detail strip occupies the lower left panel. */
    public void drawOutline(Canvas canvas, int visibleRows) {
        drawOutline(canvas, mapY(sampleY + visibleRows));
    }
    private void drawOutline(Canvas canvas, double bottom) {
        ring(canvas, bottom, 2, 0xff000000);
        ring(canvas, bottom, 1, 0xffeeeeee);
    }
    private void ring(Canvas c, double bottom, int thickness, int color) {
        fill(c, guideLeft-thickness, guideTop-thickness, guideRight+thickness, guideTop, color);
        fill(c, guideLeft-thickness, bottom, guideRight+thickness, bottom+thickness, color);
        fill(c, guideLeft-thickness, guideTop, guideLeft, bottom, color);
        fill(c, guideRight, guideTop, guideRight+thickness, bottom, color);
    }
    private void fill(Canvas c, double x0, double y0, double x1, double y1, int color) {
        x0 = Math.max(x, x0); y0 = Math.max(y, y0);
        x1 = Math.min(x+width, x1); y1 = Math.min(y+height, y1);
        if (x1 > x0 && y1 > y0) c.fill(x0, y0, x1, y1, color);
    }
}
