package dev.eyeruler;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Matrix4f;
import org.lwjgl.opengl.GL11;

public final class RulerHud {
    private static final int WHITE = 0xffeeeeee, BLUE = 0xff55c8ef;
    private static final int PANEL = 0xed111720, BORDER = 0xff485664, BLACK = 0xff000000;
    private RulerHud() {}
    private static void box(MatrixStack s, int x, int y, int w, int h, int color) {
        DrawableHelper.fill(s, x, y, x + w, y + h, color);
    }
    private static void label(MatrixStack s, InsetLayout l, String text, int x, int y, int maxWidth, int color) {
        label(s, l.scale, text, x, y, maxWidth, color);
    }
    private static void label(MatrixStack s, int scale, String text, int x, int y, int maxWidth, int color) {
        MinecraftClient c = MinecraftClient.getInstance();
        s.push();
        s.translate(x, y, 0);
        s.scale(scale, scale, 1);
        c.textRenderer.drawWithShadow(s, c.textRenderer.trimToWidth(text, Math.max(0, maxWidth / scale)), 0, 0, color);
        s.pop();
    }
    public static void draw(MatrixStack s, int outputWidth, int outputHeight, InsetLayout l) {
        MinecraftClient c = MinecraftClient.getInstance();
        Framebuffer t = EyeRuler.target;
        double guiScale = c.getWindow().getScaleFactor();
        boolean depth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        s.push();
        s.scale((float) (1 / guiScale), (float) (1 / guiScale), 1);
        try {
            // Physical center, including the half-pixel center of an odd-size framebuffer.
            crosshair(s, outputWidth / 2.0, outputHeight / 2.0);
            box(s, l.panelX, l.panelY, l.panelWidth, l.panelHeight, PANEL);
            int tx = l.panelX + l.margin, tw = l.panelWidth - 2 * l.margin;
            String title = "EYE RULER (By Mark + Astra)";
            int titleScale = Math.max(1, Math.min(l.scale, tw / (c.textRenderer.getWidth(title) + 1)));
            label(s, titleScale, title, tx, l.panelY + 4*l.scale, tw, WHITE);
            label(s, l, "Sens: " + c.options.mouseSensitivity + (EyeRuler.precision.isActive() ? " (precision)" : " (normal)"), tx, l.panelY + 15*l.scale, tw, BLUE);
            label(s, l, CopyStatus.compactSummary, tx, l.panelY + 26*l.scale, tw, WHITE);
            label(s, l, "Target: left (-) | right (+)", tx, l.panelY + 37*l.scale, tw, WHITE);

            box(s, l.x - 1, l.y - 1, l.width + 2, l.height + 2, BORDER);
            measurement(s, l, t);
            magnifier(s, l);
        } finally {
            s.pop();
            RenderSystem.color4f(1, 1, 1, 1);
            RenderSystem.enableTexture();
            if (depth) RenderSystem.enableDepthTest();
        }
    }
    private static void magnifier(MatrixStack s, InsetLayout ruler) {
        LiveViewLayout l = EyeRuler.liveView;
        box(s, l.panelX, ruler.panelY, l.panelWidth, ruler.panelHeight, PANEL);
        label(s, ruler, "LIVE EYE VIEW", l.x, ruler.panelY + 4*ruler.scale, l.width, BLUE);
        label(s, ruler, "0.2.17 | Tall " + EyeRuler.config.virtualHeight, l.x,
            ruler.panelY + 15*ruler.scale, l.width, WHITE);
        label(s, ruler, "Outline = left view", l.x,
            ruler.panelY + 26*ruler.scale, l.width, BLUE);
        box(s, l.x - 1, l.y - 1, l.width + 2, l.height + 2, BORDER);
        box(s, l.x, l.y, l.width, l.height, BLACK);
        quad(s, EyeRuler.target, (float)l.viewX, (float)l.viewY,
            (float)(l.viewX+l.viewWidth), (float)(l.viewY+l.viewHeight),
            0,1, 0,0, 1,0, 1,1);
        l.drawOutline((x0, y0, x1, y1, color) -> {
            s.push();
            s.translate(x0, y0, 0);
            s.scale((float)(x1-x0), (float)(y1-y0), 1);
            box(s, 0, 0, 1, 1, color);
            s.pop();
        });
    }
    private static void measurement(MatrixStack s, InsetLayout l, Framebuffer t) {
        sample(s, t, l.x, l.y, l.width, l.height,
            EyeRuler.liveView.sampleX, EyeRuler.liveView.sampleY, l.sampleWidth, l.height);
        OverlayCanvas canvas = new OverlayCanvas(s);
        try { RulerOverlay.draw(l, canvas); }
        finally { canvas.finish(); }
        label(s, l, l.step + " px = 1 correction", l.x,
            l.panelHeight-34*l.scale, l.width, BLUE);
        label(s, l, CopyStatus.coordinates + " | " + CopyStatus.angles, l.x,
            l.panelHeight-20*l.scale, l.width, WHITE);
    }
    /** One vertex-colored batch gives every ruler band the same rasterized edges. */
    private static final class OverlayCanvas implements RulerOverlay.Canvas {
        private final MatrixStack matrices;
        private final Matrix4f transform;
        private final BufferBuilder vertices;
        private boolean drawing = true;
        OverlayCanvas(MatrixStack matrices) {
            this.matrices = matrices;
            transform = matrices.peek().getModel();
            RenderSystem.disableTexture();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            vertices = Tessellator.getInstance().getBuffer();
            vertices.begin(GL11.GL_QUADS, VertexFormats.POSITION_COLOR);
        }
        public void fill(int x, int y, int w, int h, int color) {
            if (!drawing) throw new IllegalStateException("Ruler fills must precede labels");
            int red = (color >>> 16) & 255, green = (color >>> 8) & 255;
            int blue = color & 255, alpha = color >>> 24;
            vertices.vertex(transform, x, y+h, 0).color(red, green, blue, alpha).next();
            vertices.vertex(transform, x+w, y+h, 0).color(red, green, blue, alpha).next();
            vertices.vertex(transform, x+w, y, 0).color(red, green, blue, alpha).next();
            vertices.vertex(transform, x, y, 0).color(red, green, blue, alpha).next();
        }
        public int textWidth(String text) {
            return MinecraftClient.getInstance().textRenderer.getWidth(text);
        }
        public void text(String text, int x, int y, int scale, int color) {
            finish();
            if (color == RulerOverlay.BLACK) {
                matrices.push();
                matrices.translate(x, y, 0);
                matrices.scale(scale, scale, 1);
                MinecraftClient.getInstance().textRenderer.draw(matrices, text, 0, 0, color);
                matrices.pop();
            } else label(matrices, scale, text, x, y, (textWidth(text) + 1) * scale, color);
        }
        void finish() {
            if (!drawing) return;
            drawing = false;
            Tessellator.getInstance().draw();
            RenderSystem.enableTexture();
        }
    }
    private static void crosshair(MatrixStack s, double x, double y) {
        s.push(); s.translate(x, y, 0);
        box(s, -2, -17, 3, 14, BLACK);
        box(s, -2, 3, 3, 14, BLACK);
        box(s, -17, -1, 14, 3, BLACK);
        box(s, 3, -1, 14, 3, BLACK);
        box(s, -1, -16, 1, 12, WHITE);
        box(s, -1, 4, 1, 12, WHITE);
        box(s, -16, 0, 12, 1, WHITE);
        box(s, 4, 0, 12, 1, WHITE);
        // An open center avoids painting over the eye's measurement edge.
        s.pop();
    }
    private static void sample(MatrixStack s, Framebuffer t, int x, int y, int w, int h,
                               double sourceX, double sourceY, double sourceW, double sourceH) {
        float u0 = (float)(sourceX/t.textureWidth), u1 = (float)((sourceX+sourceW)/t.textureWidth);
        float v0 = (float)(1-sourceY/t.textureHeight), v1 = (float)(1-(sourceY+sourceH)/t.textureHeight);
        quad(s, t, x, y, x+w, y+h, u0,v0, u0,v1, u1,v1, u1,v0);
    }
    private static void quad(MatrixStack s, Framebuffer t, float x0, float y0, float x1, float y1,
                             float ua, float va, float ub, float vb, float uc, float vc, float ud, float vd) {
        RenderSystem.enableTexture(); RenderSystem.disableBlend(); RenderSystem.color4f(1, 1, 1, 1);
        t.beginRead();
        Matrix4f mat = s.peek().getModel();
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(GL11.GL_QUADS, VertexFormats.POSITION_TEXTURE);
        b.vertex(mat, x0, y0, 0).texture(ua, va).next();
        b.vertex(mat, x0, y1, 0).texture(ub, vb).next();
        b.vertex(mat, x1, y1, 0).texture(uc, vc).next();
        b.vertex(mat, x1, y0, 0).texture(ud, vd).next();
        Tessellator.getInstance().draw(); t.endRead(); RenderSystem.enableBlend();
    }
}
