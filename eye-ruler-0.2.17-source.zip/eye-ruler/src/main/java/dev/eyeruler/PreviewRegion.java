package dev.eyeruler;

import net.minecraft.util.math.Matrix4f;
import java.nio.FloatBuffer;

/** The visible measurement crop projected into the ordinary scene's clip space. */
public final class PreviewRegion {
    public final double left, top, right, bottom;

    private PreviewRegion(double[] a, double[] b) {
        left = a[0] / a[2]; top = a[1] / a[2];
        right = b[0] / b[2]; bottom = b[1] / b[2];
    }

    public static PreviewRegion project(InsetLayout crop, Matrix4f normal, Matrix4f inset) {
        Matrix4f inverse = inset.copy();
        if (!inverse.invert()) return null;
        Matrix4f mapping = normal.copy();
        mapping.multiply(inverse);
        FloatBuffer matrix = FloatBuffer.allocate(16);
        mapping.writeToBuffer(matrix);
        // Pixel EDGES of the displayed crop, excluding the framebuffer's padding.
        double[] a = transform(matrix, 2.0 * crop.sampleX / crop.sourceWidth - 1,
            1 - 2.0 * crop.sampleY / crop.sourceHeight);
        double[] b = transform(matrix, 2.0 * (crop.sampleX + crop.sampleWidth) / crop.sourceWidth - 1,
            1 - 2.0 * (crop.sampleY + crop.height) / crop.sourceHeight);
        if (!(a[2] > 0 && b[2] > 0)) return null;
        PreviewRegion region = new PreviewRegion(a, b);
        if (!Double.isFinite(region.left) || !Double.isFinite(region.right)
            || !Double.isFinite(region.top) || !Double.isFinite(region.bottom)
            || region.left >= region.right || region.bottom >= region.top) return null;
        return region;
    }

    private static double[] transform(FloatBuffer m, double x, double y) {
        // Public column-major buffer API; input clip coordinates are (x, y, 0, 1).
        return new double[] {m.get(0)*x + m.get(4)*y + m.get(12),
            m.get(1)*x + m.get(5)*y + m.get(13),
            m.get(3)*x + m.get(7)*y + m.get(15)};
    }

    public Bounds inMagnifier(MagnifierLayout view, int screenWidth, int screenHeight) {
        double sx = screenWidth * view.zoom / 2.0;
        double sy = screenHeight * view.zoom / 2.0;
        return new Bounds(view.centerX() + left * sx, view.centerY() - top * sy,
            view.centerX() + right * sx, view.centerY() - bottom * sy);
    }

    public static final class Bounds {
        public final double left, top, right, bottom;
        public Bounds(double left, double top, double right, double bottom) {
            this.left = left; this.top = top; this.right = right; this.bottom = bottom;
        }
        public boolean fits(MagnifierLayout view) {
            return left >= view.x && top >= view.y
                && right <= view.x + view.width && bottom <= view.y + view.height;
        }
    }
}
