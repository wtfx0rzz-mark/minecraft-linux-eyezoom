package dev.eyeruler;

import net.minecraft.client.util.math.MatrixStack;

public final class RenderPose {
    private RenderPose() {}

    /** WorldRenderer requires a stack with only its root entry, even between entity draws. */
    public static MatrixStack copyRoot(MatrixStack source) {
        MatrixStack result = new MatrixStack();
        result.peek().getModel().multiply(source.peek().getModel());
        result.peek().getNormal().load(source.peek().getNormal());
        return result;
    }
}
