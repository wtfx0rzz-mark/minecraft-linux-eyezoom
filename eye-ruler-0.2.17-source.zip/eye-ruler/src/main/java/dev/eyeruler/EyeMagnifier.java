package dev.eyeruler;

// Retired ordinary-scene copy. Both panels now use EyeRuler.target each frame.
