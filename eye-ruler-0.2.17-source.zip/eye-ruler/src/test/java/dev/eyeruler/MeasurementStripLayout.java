package dev.eyeruler;

/** A second drawing of central live texels; never a capture or a separate render. */
public final class MeasurementStripLayout {
    public final boolean visible;
    public final int panelTop, mainHeight, x, y, width, imageHeight;
    public final int sourceX, sourceY, sourceWidth, sourceHeight, step, verticalScale;
    public final RulerOverlay.Geometry overlay;

    public MeasurementStripLayout(InsetLayout main, LiveViewLayout live) {
        // Leave a full source column beyond each endpoint for its number.
        step = Math.max(1, Math.min(2 * main.step, main.width / (2 * main.range + 2)));
        sourceWidth = Math.max(2, (main.width / step) & ~1);
        width = sourceWidth * step;
        x = main.centerX() - width / 2;
        verticalScale = 2;
        int digits = Integer.toString(main.range).length();
        int labelScale = Math.max(1, Math.min(4, step / (6 * digits)));
        int labelRows = Math.max(1, (6 * digits * labelScale + step - 1) / step);
        int barHeight = Math.max(main.barHeight, 14 * labelScale);
        int header = 12 * main.scale;
        int labelArea = (10 * labelRows + 4) * labelScale;
        int gap = 4 * main.scale;
        int belowLabels = main.y + main.height - (main.labelY
            + (10 * main.labelRows + 2) * main.rulerLabelScale + gap);
        int budget = Math.min(main.height / 3, belowLabels);
        int availableImage = budget - header - barHeight - labelArea - 2 * gap;
        sourceHeight = Math.max(0, Math.min(128, availableImage / verticalScale)) & ~1;
        imageHeight = sourceHeight * verticalScale;
        int totalHeight = header + imageHeight + barHeight + labelArea + gap;
        panelTop = main.y + main.height - totalHeight;
        y = panelTop + header;
        sourceX = (live.sourceWidth - sourceWidth) / 2;
        sourceY = (live.sourceHeight - sourceHeight) / 2;
        // If there is no useful enlargement, leave the original layout intact.
        visible = main.visible && step > main.step && sourceHeight >= 32
            && sourceWidth >= 2 * main.range + 2 && sourceWidth <= main.sampleWidth;
        mainHeight = visible ? panelTop - gap - main.y : main.height;
        int barY = y + imageHeight;
        overlay = new RulerOverlay.Geometry(main.scale, y, totalHeight - header,
            main.centerX(), main.panelX, main.panelWidth, main.range, step,
            barY, barHeight, labelScale, barY + barHeight + 2 * labelScale, labelRows, barY);
    }
}
