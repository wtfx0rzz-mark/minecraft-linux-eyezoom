package dev.eyeruler;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import javax.imageio.ImageIO;

/** End-to-end geometry checks for the expanded ruler and relocated live context view. */
public final class OppositePanelsCheck {
    public static void main(String[] args) throws Exception {
        int cases=0;
        for(int[] size:new int[][]{{640,480},{1280,720},{1920,1080},{2047,1109},{3708,2022},{3840,2160}})
        for(int magnification:new int[]{5,12,24})
        for(int range:new int[]{9,12,16})
        for(int context:new int[]{256,1024,2048}) {
            InsetLayout old=layout(size[0],size[1],magnification,Math.min(9,range),false);
            InsetLayout r=layout(size[0],size[1],magnification,range,true);
            LiveViewLayout previous=new LiveViewLayout(old,context),v=new LiveViewLayout(r,context);
            MeasurementStripLayout formerStrip=new MeasurementStripLayout(old,previous);
            require(r.visible==old.visible,"Supported window lost the overlay");
            require(r.panelX==0 && v.panelX+v.panelWidth==size[0],"Panels are not anchored to opposing edges");
            if(r.visible) {
                require(r.panelX+r.panelWidth<=size[0]/2-r.centerSafetyGap,"Left panel covers aiming clearance");
                require(v.panelX>=size[0]/2+r.centerSafetyGap,"Right panel covers aiming clearance");
            }
            require(r.sampleWidth==old.sampleWidth && r.height==old.height,"Eye coverage reduced");
            require(r.sourceWidth==old.sourceWidth && r.sourceHeight==old.sourceHeight,"Minimal source changed");
            require(v.sourceWidth==previous.sourceWidth && v.sourceHeight==previous.sourceHeight,"Shared render/projection dimensions changed");
            require(v.sampleX==previous.sampleX && v.sampleY==previous.sampleY,"Eye source rectangle shifted");
            require(v.width==previous.width && v.height==previous.height,"Right eye viewport resized");
            near(v.displayScale,previous.displayScale); near(v.viewWidth,previous.viewWidth); near(v.viewHeight,previous.viewHeight);
            near(v.viewY,previous.viewY); near(v.viewX-v.panelX,previous.viewX-previous.panelX);
            require(r.step>=old.step && r.step<=2*old.step,"Incorrect enlargement");
            if(formerStrip.visible) {
                require(r.step==formerStrip.step,"Bands do not match the bottom ruler the user chose");
                require(r.rulerLabelScale<=formerStrip.overlay.rulerLabelScale,"Compact numbers got larger");
                require(r.barHeight==formerStrip.overlay.barHeight,"Colored band height differs from chosen ruler");
            }
            // Simulate production float-UV interpolation at every screen pixel in every signed band.
            float u0=(float)((double)v.sampleX/v.sourceWidth),u1=(float)((double)(v.sampleX+r.sampleWidth)/v.sourceWidth);
            for(int i=-r.range;i<r.range;i++) for(int dx=0;dx<r.step;dx++) {
                double x=r.rulerX(i)+dx+0.5;
                int source=(int)Math.floor((u0+(u1-(double)u0)*(x-r.x)/r.width)*v.sourceWidth);
                require(source==v.sourceWidth/2+i,"Calibration mismatch at signed offset "+i);
            }
            float top=(float)(1-(double)v.sampleY/v.sourceHeight),bottom=(float)(1-(double)(v.sampleY+r.height)/v.sourceHeight);
            for(int row=0;row<r.height;row++) {
                int source=v.sourceHeight-1-(int)Math.floor((top+(bottom-(double)top)*(row+0.5)/r.height)*v.sourceHeight);
                require(source==v.sampleY+row,"Vertical rows were cropped, stretched or flipped");
            }
            near(v.guideLeft,v.mapX(v.sampleX)); near(v.guideRight,v.mapX(v.sampleX+r.sampleWidth));
            near(v.guideTop,v.mapY(v.sampleY)); near(v.guideBottom,v.mapY(v.sampleY+r.height));
            near(v.guideRight-v.guideLeft,previous.guideRight-previous.guideLeft);
            v.drawOutline((x0,y0,x1,y1,color)-> {
                require(x0>=v.x && x1<=v.x+v.width && y0>=v.y && y1<=v.y+v.height,"Outline outside eye viewport");
                require(x1<=v.guideLeft || x0>=v.guideRight || y1<=v.guideTop || y0>=v.guideBottom,"Outline covers its sample interior");
            });
            cases++;
        }
        if(args.length>0) {
            BufferedImage font;
            try(InputStream in=OppositePanelsCheck.class.getResourceAsStream("/assets/minecraft/textures/font/ascii.png")) {
                require(in!=null,"Missing Minecraft font");font=ImageIO.read(in);
            }
            for(int[] size:new int[][]{{1920,1080},{3708,2022}}) {
                InsetLayout r=layout(size[0],size[1],12,12,true);
                LiveViewLayout v=new LiveViewLayout(r,1024);
                require(r.range==12 && r.labelsInside && r.labelRows==1,"Desktop does not fit all 24 labels inside bar");
                require(r.width==(size[0]==1920?680:1440),"Left width changed from 0.2.16");
                require(r.step==(size[0]==1920?20:24),"Correction width changed from 0.2.16");
                require(r.barHeight==(size[0]==1920?42:56),"Band height changed from 0.2.16");
                require(r.rulerLabelScale==(size[0]==1920?1:2),"Compact font size incorrect");
                BufferedImage image=render(size[0],size[1],r,v,font);
                File file=new File(args[0],"opposite-panels-"+size[0]+".png");file.getParentFile().mkdirs();
                ImageIO.write(image,"png",file);
                System.out.println(size[0]+"x"+size[1]+": left "+r.width+"x"+r.height+", "+r.step
                    +" px/correction, font "+r.rulerLabelScale+", right "+v.width+"x"+v.height+" at x="+v.panelX
                    +", source "+v.sourceWidth+"x"+v.sourceHeight);
            }
        }
        System.out.println("PASS: "+cases+" opposite-panel layouts; selected ruler sizes, full coverage, unchanged right zoom, signed UVs and center clearance");
    }
    private static InsetLayout layout(int w,int h,int mag,int range,boolean wide) {
        return new InsetLayout(w,h,0,720,650,3,mag,range,true,32,3,wide);
    }
    private static BufferedImage render(int width,int height,InsetLayout r,LiveViewLayout v,BufferedImage font) {
        BufferedImage image=new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);
        Graphics2D g=image.createGraphics();
        g.setColor(new Color(0xff344757,true));g.fillRect(0,0,width,height);
        g.setColor(new Color(RulerOverlay.BACKGROUND,true));
        g.fillRect(r.panelX,0,r.panelWidth,height);g.fillRect(v.panelX,0,v.panelWidth,height);
        BufferedImage source=new BufferedImage(v.sourceWidth,v.sourceHeight,BufferedImage.TYPE_INT_RGB);
        int[] colors={0xff183b35,0xff30492a,0xff426126,0xff173028};
        for(int y=0;y<source.getHeight();y++)for(int x=0;x<source.getWidth();x++) {
            int dx=x-source.getWidth()/2,dy=y-source.getHeight()/2;
            boolean eye=dx*dx/(170.0*170)+dy*dy/(210.0*210)<1;
            int color=eye?colors[Math.floorMod(dx/35+dy/45,4)]:0xff85b6ea;
            if(eye && dx>=3 && dx<36 && Math.abs(dy)<125)color=0xff071510;
            source.setRGB(x,y,color);
        }
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        OverlayCheck.Canvas canvas=new OverlayCheck.Canvas(r,font);
        canvas.g.drawImage(source,r.x,r.y,r.x+r.width,r.y+r.height,v.sampleX,v.sampleY,v.sampleX+r.sampleWidth,v.sampleY+r.height,null);
        RulerOverlay.draw(r,canvas);
        // Only copy the left panel; its test canvas includes padding beyond its edge.
        g.drawImage(canvas.image,0,0,r.panelWidth,height,0,0,r.panelWidth,height,null);canvas.g.dispose();
        g.drawImage(source,(int)v.viewX,(int)v.viewY,(int)(v.viewX+v.viewWidth),(int)(v.viewY+v.viewHeight),0,0,v.sourceWidth,v.sourceHeight,null);
        v.drawOutline((x0,y0,x1,y1,color)-> {g.setColor(new Color(color,true));g.fill(new Rectangle2D.Double(x0,y0,x1-x0,y1-y0));});
        g.setFont(new java.awt.Font("SansSerif",java.awt.Font.PLAIN,10*r.scale));g.setColor(Color.WHITE);
        g.drawString("ONE RULER | "+r.step+" px / correction",r.x,35*r.scale);
        g.drawString("LIVE EYE VIEW",v.x,20*r.scale);
        g.drawString("SYNTHETIC LAYOUT CHECK",r.panelWidth+12,30*r.scale);
        g.fillRect(width/2-16,height/2,33,1);g.fillRect(width/2,height/2-16,1,33);
        g.dispose();return image;
    }
    private static void require(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    private static void near(double a,double b){require(Math.abs(a-b)<1e-8,a+" != "+b);}
}
