package dev.eyeruler;

public final class RevisionCheck {
    public static void main(String[] args) {
        int n = 0;
        for (int[] size : new int[][] {{1280,720},{1920,1080},{2048,1110},{2560,1440},{3840,2160}}) {
            for (int m : new int[] {2,4,5,8,12}) {
                InsetLayout l = new InsetLayout(size[0], size[1], 0, 720, 650, 3, m, 8, true, 32, 3);
                require(l.scale >= 2, "Automatic labels too small");
                require(l.visible, "Inset hidden at a supported resolution");
                require(l.stripWidth <= l.width && l.stripX >= l.x, "Detail panel overflow");
                require(l.range <= l.sourceWidth / 2, "Sampling outside texture");
                require(l.y == 48*l.scale && l.panelHeight-42*l.scale-l.y-l.height <= 1,
                    "Preview does not use vertical space");
                require(l.panelX + 2*l.panelWidth <= size[0]/2 - 48*l.scale, "Main crosshair safety gap lost");
                require(l.step == m, "UI scale changed measurement magnification");
                require(l.stripX == l.x && l.stripWidth == l.width && l.stripHeight == l.height, "Measurement preview does not fill panel");
                n++;
            }
        }
        InsetLayout desktop = new InsetLayout(3708,2022,0,720,650,3,24,8,true,32,3);
        require(desktop.width == 720 && desktop.height == 1662 && desktop.divisor == 1, "User resolution defaults wrong");
        require(desktop.sampleWidth==30 && desktop.sourceWidth==32 && desktop.sourceHeight==1664,
            "User resolution no longer has 30 visible columns in a 32x1664 buffer");
        require(desktop.rulerLabelScale==3 && desktop.labelY>desktop.barY+desktop.barHeight,
            "Digits must be larger and below the color bar");
        require(desktop.width>desktop.rulerX(8)-desktop.rulerX(-8), "Context outside the ruler lost");
        require(desktop.range == 8 && desktop.labelStep == 1 && desktop.step == 24,
            "Default +/-8 range, numbering or large bands lost");
        for (int[] size : new int[][] {{1280,720},{1920,1080},{2047,1109},{3840,2160}}) {
            InsetLayout l = new InsetLayout(size[0],size[1],0,720,650,3,24,8,true,32,3);
            require(l.visible && l.range==8 && l.labelStep==1, "Short ruler clipped/thinned");
            require(l.rulerX(8)-l.rulerX(-8)==16*l.step, "Signed endpoints wrong");
        }
        require(!CopyStatus.isMeasurement("unrelated clipboard text"), "Unrelated clipboard accepted");
        require(!CopyStatus.isMeasurement("/execute in minecraft:overworld run tp @s NaN 64 1 1 -1"), "NaN accepted");
        String p = "/execute in minecraft:overworld run tp @s 10.00 64.00 -50.00 12.34 -31.60";
        require(CopyStatus.isMeasurement(p), "Vanilla format rejected");
        CopyStatus.record(p, true);
        require(CopyStatus.summary.contains("verified") && CopyStatus.details.contains("12.34"), "Missing copy details");
        CopyStatus.record(p, true);
        require(CopyStatus.hint.contains("duplicates"), "Missing duplicate guidance");
        CopyStatus.record(p.replace("-31.60", "20.00"), true);
        require(CopyStatus.hint.contains("Looking down"), "Missing pitch guidance");
        CopyStatus.record(p.replace("overworld", "the_nether"), false);
        require(CopyStatus.hint.contains("Outside Overworld") && CopyStatus.summary.contains("failed"), "Misleading status");
        require(CopyStatus.coordinates.contains("10.00") && CopyStatus.angles.contains("12.34"), "Compact details lost");
        System.out.println("PASS: " + n + " inset layout/eye-coverage cases and clipboard diagnostics");
    }
    private static void require(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
}
