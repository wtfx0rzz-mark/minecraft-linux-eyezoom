package dev.eyeruler;

import java.nio.FloatBuffer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.util.math.Matrix3f;
import net.minecraft.util.math.Matrix4f;

/** Exercises Minecraft's actual matrix stack without requiring an OpenGL context. */
public final class RenderPoseCheck {
    public static void main(String[] args) {
        MatrixStack old = new MatrixStack();
        require(old.isEmpty(), "Fresh stack is not at root");
        old.push();
        require(!old.isEmpty(), "0.2.0 crash condition not reproduced");
        old.pop();

        int cases = 0;
        for (float yaw : new float[] {0, 90, -179, 333.65f}) {
            for (float pitch : new float[] {-89, -31.25f, 0, 60}) {
                MatrixStack main = new MatrixStack();
                main.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(pitch));
                main.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(yaw + 180));
                Matrix4f modelBefore = main.peek().getModel().copy();
                Matrix3f normalBefore = main.peek().getNormal().copy();

                MatrixStack inset = RenderPose.copyRoot(main);
                require(inset.isEmpty(), "Inset would fail WorldRenderer.checkEmpty");
                require(main.isEmpty(), "Main stack gained an entry");
                near(inset.peek().getModel(), modelBefore);
                require(inset.peek().getNormal().equals(normalBefore), "Normal transform changed");
                require(inset.peek().getModel() != main.peek().getModel(), "Shared model matrix");
                require(inset.peek().getNormal() != main.peek().getNormal(), "Shared normal matrix");

                // Nested entity transforms must unwind to a root accepted by WorldRenderer.
                inset.push();
                inset.translate(3, -2, 7);
                inset.scale(2, 3, 4);
                inset.pop();
                require(inset.isEmpty(), "Entity pass did not return to the root");
                near(inset.peek().getModel(), modelBefore);

                // Even a failed pass leaving an extra inset entry cannot damage the main view.
                inset.push();
                inset.translate(9, 5, -11);
                require(main.isEmpty() && main.peek().getModel().equals(modelBefore)
                    && main.peek().getNormal().equals(normalBefore), "Inset mutated main camera state");
                cases++;
            }
        }
        System.out.println("PASS: reproduced 0.2.0 stack-depth fault; " + cases
            + " real Minecraft pose/camera isolation regression cases");
    }
    private static void near(Matrix4f actual, Matrix4f expected) {
        FloatBuffer a = FloatBuffer.allocate(16), b = FloatBuffer.allocate(16);
        actual.writeToBuffer(a); expected.writeToBuffer(b);
        for (int i = 0; i < 16; i++) require(Math.abs(a.get(i)-b.get(i)) < 1e-6f, "Camera pose differs");
    }
    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
}
