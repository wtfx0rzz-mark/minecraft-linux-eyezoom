package dev.eyeruler;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import net.minecraft.util.math.Matrix4f;

/** Compares actual Minecraft projection matrices with independent camera-ray geometry. */
public final class PreviewRegionCheck {
    public static void main(String[] args) throws Exception {
        int cases = 0;
        for (int[] size : new int[][] {{640,480},{1280,720},{1920,1080},{2047,1109},{3708,2022},{3840,2160}})
        for (int scale : new int[] {0,1,3})
        for (int panelWidth : new int[] {160,720,1200})
        for (int virtualHeight : new int[] {1024,16384,32768})
        for (double fov : new double[] {30,70,110,35.5})
        for (int zoom : new int[] {2,7,14,28}) {
            InsetLayout r = layout(size[0], size[1], scale, panelWidth);
            if (!r.visible) continue;
            MagnifierLayout m = new MagnifierLayout(r, size[0], size[1], zoom);
            Matrix4f normal = Matrix4f.viewboxMatrix(fov, size[0]/(float)size[1], 0.05f, 512);
            Matrix4f inset = Matrix4f.viewboxMatrix(Projection.fov(r.sourceHeight, virtualHeight),
                r.sourceWidth/(float)r.sourceHeight, 0.05f, 512);
            Matrix4f beforeNormal = normal.copy(), beforeInset = inset.copy();
            PreviewRegion region = PreviewRegion.project(r, normal, inset);
            require(region != null, "Valid projection rejected");
            require(normal.equals(beforeNormal) && inset.equals(beforeInset), "Projection was mutated");
            PreviewRegion.Bounds b = region.inMagnifier(m, size[0], size[1]);
            // Independent pinhole-camera focal lengths (no matrix inversion).
            double normalFocal = size[1] / (2 * Math.tan(Math.toRadians(fov / 2)));
            double tallFocal = virtualHeight / (2 * Math.tan(Math.toRadians(15)));
            double ratio = zoom * normalFocal / tallFocal;
            near(b.left, m.centerX() - r.sampleWidth * ratio / 2);
            near(b.right, m.centerX() + r.sampleWidth * ratio / 2);
            near(b.top, m.centerY() - r.height * ratio / 2);
            near(b.bottom, m.centerY() + r.height * ratio / 2);
            // Every visible source-column boundary lands at its corresponding box fraction.
            for (int col = 0; col <= r.sampleWidth; col++) {
                double rayX = (col-r.sampleWidth/2.0)/tallFocal;
                near(b.left+(b.right-b.left)*col/r.sampleWidth, m.centerX()+zoom*normalFocal*rayX);
            }
            for (int row : new int[] {0,r.height/2,r.height}) {
                double rayY = (row-r.height/2.0)/tallFocal;
                near(b.top+(b.bottom-b.top)*row/r.height, m.centerY()+zoom*normalFocal*rayY);
            }
            verifyPainter(b, m);
            cases++;
        }
        InsetLayout r = layout(3708,2022,0,720);
        MagnifierLayout m = new MagnifierLayout(r,3708,2022,14);
        Matrix4f normal = Matrix4f.viewboxMatrix(70,3708f/2022,0.05f,512);
        Matrix4f inset = Matrix4f.viewboxMatrix(Projection.fov(r.sourceHeight,16384),
            r.sourceWidth/(float)r.sourceHeight,0.05f,512);
        PreviewRegion base = PreviewRegion.project(r,normal,inset);
        // A live projection change must move/resize the box; the options FOV is insufficient.
        Matrix4f changed = Matrix4f.translate(0.02f,-0.015f,0);
        changed.multiply(Matrix4f.scale(1.2f,1.1f,1));
        changed.multiply(normal);
        PreviewRegion moved = PreviewRegion.project(r,changed,inset);
        near(moved.left,base.left*1.2+0.02);
        near(moved.top,base.top*1.1-0.015);
        near(moved.right,base.right*1.2+0.02);
        near(moved.bottom,base.bottom*1.1-0.015);
        require(PreviewRegion.project(r,normal,new Matrix4f()) == null, "Singular projection accepted");
        // An oversized region must not invent border edges at the magnifier boundary.
        PreviewRegion.Bounds outside = new PreviewRegion.Bounds(m.x-10,m.y-10,m.x+m.width+10,m.y+m.height+10);
        int[] count = {0};
        PreviewOutline.draw(outside,m,(x0,y0,x1,y1,c)->count[0]++);
        require(count[0] == 0, "Oversized region was falsely boxed inside view");
        if (args.length > 0) renderSample(args[0]);
        System.out.println("PASS: " + cases + " real projection/crop cases, source boundaries, live projection changes,"
            + " transparent interiors and clipped outline strokes");
    }
    private static InsetLayout layout(int w, int h, int scale, int panelWidth) {
        return new InsetLayout(w,h,scale,panelWidth,650,3,24,8,true,32,3);
    }
    private static void verifyPainter(PreviewRegion.Bounds a, MagnifierLayout v) {
        PreviewOutline.draw(a,v,(x0,y0,x1,y1,c)->{
            require(x0 >= v.x && y0 >= v.y && x1 <= v.x+v.width && y1 <= v.y+v.height,
                "Outline escaped magnifier");
            require(x1 > x0 && y1 > y0, "Empty stroke");
            require(x1 <= a.left || x0 >= a.right || y1 <= a.top || y0 >= a.bottom,
                "Outline covered the sampled interior");
        });
    }
    private static void renderSample(String path) throws Exception {
        BufferedImage image = new BufferedImage(1200,690,BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setColor(new Color(0x111720)); g.fillRect(0,0,1200,690);
        g.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,18));
        double[] fovs = {30,70,110};
        for (int i=0;i<fovs.length;i++) {
            InsetLayout r=layout(1920,1080,0,720);
            MagnifierLayout m=new MagnifierLayout(r,1920,1080,14);
            Matrix4f normal=Matrix4f.viewboxMatrix(fovs[i],1920f/1080,0.05f,512);
            Matrix4f inset=Matrix4f.viewboxMatrix(Projection.fov(r.sourceHeight,16384),
                r.sourceWidth/(float)r.sourceHeight,0.05f,512);
            PreviewRegion.Bounds b=PreviewRegion.project(r,normal,inset).inMagnifier(m,1920,1080);
            int ox=i*400+8, oy=55;
            double shrink=620.0/m.height;
            g.setColor(new Color(0xeeeeee));
            g.drawString("FOV "+(int)fovs[i]+" / 14x view",ox,30);
            g.translate(ox,oy); g.scale(1,shrink); g.translate(-m.x,-m.y);
            for(int y=m.y;y<m.y+m.height;y+=28) for(int x=m.x;x<m.x+m.width;x+=28) {
                g.setColor(new Color((((x-m.x)/28+(y-m.y)/28)&1)==0?0x304a3f:0x86b2ee));
                g.fillRect(x,y,Math.min(28,m.x+m.width-x),Math.min(28,m.y+m.height-y));
            }
            PreviewOutline.draw(b,m,(x0,y0,x1,y1,c)->{
                g.setColor(new Color(c,true)); g.fill(new Rectangle2D.Double(x0,y0,x1-x0,y1-y0));
            });
            g.translate(m.x,m.y); g.scale(1,1/shrink); g.translate(-ox,-oy);
        }
        g.dispose();
        File out=new File(path); out.getParentFile().mkdirs(); ImageIO.write(image,"png",out);
    }
    private static void near(double a,double b) {
        // Minecraft's projection matrices use floats. Extreme zoom with a low
        // virtual height can put clipped edges tens of thousands of pixels away,
        // where a handful of float ULPs exceeds 0.005 px. Keep the original tight
        // tolerance for normal on-screen coordinates; allow rounding at distant edges.
        double tolerance = Math.max(0.005, 4.0 * Math.ulp((float)b));
        require(Math.abs(a-b)<tolerance,"Mapping differs: "+a+" != "+b);
    }
    private static void require(boolean ok,String message) { if(!ok)throw new AssertionError(message); }
}
