package dev.eyeruler;

public final class PrecisionSensitivityCheck {
    public static void main(String[] args) {
        PrecisionSensitivity p = new PrecisionSensitivity();
        for (double initial : new double[] {0.0, 0.5, 1.0, 0.00854642417612469, 0.012727597}) {
            equal(p.toggle(initial), 0.012727597);
            require(p.isActive());
            equal(p.toggle(0.012727597), initial);
            require(!p.isActive());
            p.toggle(initial);
            equal(p.restore(0.012727597), initial);
            equal(p.restore(initial), initial);
        }
        p.toggle(0.5);
        // A manual slider change must survive cleanup and become the next saved value.
        equal(p.restore(0.8), 0.8);
        require(!p.isActive());
        equal(p.toggle(0.8), 0.012727597);
        equal(p.toggle(0.012727597), 0.8);
        p.toggle(0.5);
        p.sync(0.0);
        require(!p.isActive());
        equal(p.toggle(0.0), 0.012727597);
        equal(p.toggle(0.012727597), 0.0);
        System.out.println("PASS: exact precision sensitivity, restoration, repeated toggles and external slider changes");
    }
    private static void equal(double actual, double expected) {
        require(Double.compare(actual, expected) == 0);
    }
    private static void require(boolean value) { if (!value) throw new AssertionError(); }
}
