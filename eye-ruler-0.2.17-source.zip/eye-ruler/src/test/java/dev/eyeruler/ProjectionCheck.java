package dev.eyeruler;

public final class ProjectionCheck {
    public static void main(String[] args) {
        int cases = 0;
        for (int virtual : new int[] {1024, 8192, 16384, 32768}) {
            double expectedFocalLength = virtual / (2 * Math.tan(Math.toRadians(15)));
            for (int crop : new int[] {90, 270, 540, 1080}) {
                double focalLength = crop / (2 * Math.tan(Math.toRadians(Projection.fov(crop, virtual) / 2)));
                near(focalLength, expectedFocalLength, 1e-8);
                for (double pitch : new double[] {0, -15, -30, 45}) {
                    double reference = Math.toDegrees(Math.atan(2 * Math.tan(Math.toRadians(15)) / virtual)) / Math.cos(Math.toRadians(pitch));
                    near(Projection.correction(virtual, pitch), reference, 1e-12);
                    // A pixel adjacent to the optical axis must subtend the angle Ninbot expects.
                    double projected = Math.toDegrees(Math.atan(1 / focalLength));
                    near(projected, reference * Math.cos(Math.toRadians(pitch)), 1e-12);
                    cases++;
                }
            }
        }
        System.out.println("PASS: " + cases + " projection / Ninjabrain pixel-correction cases");
    }
    private static void near(double actual, double expected, double tolerance) {
        if (!Double.isFinite(actual) || Math.abs(actual - expected) > tolerance) throw new AssertionError(actual + " != " + expected);
    }
}
