package dev.eyeruler;

import com.google.gson.Gson;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigCheck {
    public static void main(String[] args) throws Exception {
        Path directory = Files.createTempDirectory("eye-ruler-config-check-");
        Path path = directory.resolve("eye-ruler.json");
        try {
            defaults(Config.load(path));
            require(Files.exists(path), "Fresh config not saved");
            defaults(new Gson().fromJson(read(path), Config.class));
            write(path, "{\"schemaVersion\":3,\"magnification\":4,\"panelWidth\":480,\"panelHeight\":560,\"overviewDivisor\":4}");
            defaults(Config.load(path));
            String migrated = read(path);
            defaults(Config.load(path));
            require(read(path).equals(migrated), "Migration repeated on reload");
            write(path, "{\"schemaVersion\":2,\"magnification\":3.5,\"rulerRange\":24}");
            defaults(Config.load(path));
            require(Config.load(path).rulerRange == 12, "Legacy range migration lost");
            write(path, "{\"schemaVersion\":4,\"magnification\":5,\"rulerRange\":60}");
            defaults(Config.load(path));
            write(path, "{\"schemaVersion\":6,\"magnification\":24,\"rulerRange\":8,\"panelWidth\":600}");
            defaults(Config.load(path));
            write(path, "{\"schemaVersion\":7,\"magnification\":24,\"panelWidth\":600}");
            require(Config.load(path).panelWidth==600, "Intentional schema-7 panel width migrated again");
            cZoom(Config.load(path),14,7);
            require(new Gson().fromJson(read(path),Config.class).schemaVersion==11, "Preview defaults not persisted during migration");
            write(path,"{\"schemaVersion\":8,\"previewZoom\":12,\"previewOverviewZoom\":5}");
            cZoom(Config.load(path),12,5);
            write(path,"{\"schemaVersion\":8,\"previewZoom\":999,\"previewOverviewZoom\":-1}");
            cZoom(Config.load(path),28,2);
            write(path, "{\"schemaVersion\":6,\"magnification\":5,\"rulerRange\":60}");
            require(Config.load(path).magnification == 5 && Config.load(path).rulerRange == 60, "Current-schema customization migrated");
            write(path, "{\"schemaVersion\":3,\"magnification\":7,\"panelWidth\":740,\"panelHeight\":820,"
                + "\"overviewDivisor\":2,\"detailSourceThickness\":24,\"detailCrossScale\":4,"
                + "\"virtualHeight\":8192,\"rulerRange\":90,\"leftRuler\":false,\"uiScale\":1}");
            Config c = Config.load(path);
            require(c.magnification==7 && c.panelWidth==740 && c.panelHeight==820 && c.overviewDivisor==2, "Custom view settings overwritten");
            require(c.detailSourceThickness==24 && c.detailCrossScale==4, "Custom detail settings overwritten");
            require(c.virtualHeight==8192 && c.rulerRange==90 && !c.leftRuler && c.uiScale==1, "Unrelated settings changed");
            write(path, "{\"schemaVersion\":6,\"magnification\":4,\"panelWidth\":480,\"panelHeight\":560,\"overviewDivisor\":4}");
            c = Config.load(path);
            require(c.magnification==4 && c.panelWidth==480 && c.panelHeight==560 && c.overviewDivisor==4, "Explicit current-schema choices migrated");
            write(path, "{\"schemaVersion\":6,\"magnification\":4.6,\"detailSourceThickness\":25,\"detailCrossScale\":99,\"uiScale\":-1}");
            c = Config.load(path);
            require(c.magnification==5 && c.detailSourceThickness==24 && c.detailCrossScale==6 && c.uiScale==0, "Geometry normalization failed");
            write(path, "{\"schemaVersion\":6,\"magnification\":\"NaN\",\"detailSourceThickness\":-99,\"detailCrossScale\":0}");
            c = Config.load(path);
            require(c.magnification==12 && c.detailSourceThickness==2 && c.detailCrossScale==1, "Invalid geometry not clamped");
            write(path, "{\"schemaVersion\":8,\"magnification\":24,\"rulerRange\":8}");
            defaults(Config.load(path));
            String upgraded = read(path);
            defaults(Config.load(path));
            require(read(path).equals(upgraded), "Live view migration repeated");
            write(path, "{\"schemaVersion\":9,\"magnification\":24,\"rulerRange\":8,\"liveViewWidth\":1400}");
            c = Config.load(path);
            require(c.magnification==24 && c.rulerRange==8 && c.liveViewWidth==1400, "New-schema customization overwritten");
            write(path, "{\"schemaVersion\":9,\"liveViewWidth\":-10}");
            require(Config.load(path).liveViewWidth==256, "Live view minimum not bounded");
            write(path, "{\"schemaVersion\":9,\"liveViewWidth\":99999}");
            require(Config.load(path).liveViewWidth==2048, "Live view maximum not bounded");
            write(path, "{\"schemaVersion\":9,\"magnification\":12,\"rulerRange\":16}");
            defaults(Config.load(path));
            String nine = read(path);
            defaults(Config.load(path));
            require(read(path).equals(nine), "Nine-per-side migration repeated");
            write(path, "{\"schemaVersion\":10,\"rulerRange\":16}");
            require(Config.load(path).rulerRange==16, "Intentional current range overwritten");
            write(path, "{\"schemaVersion\":10,\"rulerRange\":9}");
            defaults(Config.load(path));
            String twelve=read(path);
            defaults(Config.load(path));
            require(read(path).equals(twelve),"Twelve-per-side migration repeated");
            write(path, "{\"schemaVersion\":11,\"rulerRange\":9}");
            require(Config.load(path).rulerRange==9,"Explicit schema-11 range overwritten");
            System.out.println("PASS: fresh config, schema 2/3 migration, persisted reload, custom/current settings, integer scales and bounds");
        } finally {
            Files.deleteIfExists(path);
            Files.deleteIfExists(directory);
        }
    }
    private static void defaults(Config c) {
        require(c.schemaVersion==11 && c.virtualHeight==16384 && c.magnification==12 && c.rulerRange==12, "Wrong calibration/scale defaults");
        require(c.panelWidth==720 && c.panelHeight==650 && c.overviewDivisor==3, "Wrong preview defaults");
        require(c.detailSourceThickness==32 && c.detailCrossScale==3, "Wrong detail defaults");
        cZoom(c,14,7);
        require(c.liveViewWidth==1024, "Live view width default lost");
    }
    private static void cZoom(Config c,int fine,int overview) {
        require(c.previewZoom==fine && c.previewOverviewZoom==overview,"Preview zoom defaults/customization lost");
    }
    private static void write(Path path, String text) throws Exception { Files.write(path, text.getBytes(StandardCharsets.UTF_8)); }
    private static String read(Path path) throws Exception { return new String(Files.readAllBytes(path), StandardCharsets.UTF_8); }
    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
}
