package dev.eyeruler;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/** Runs the production overlay painter on a synthetic pixel grid, with Minecraft's digit bitmap. */
public final class OverlayCheck {
    static final class Canvas implements RulerOverlay.Canvas {
        final BufferedImage image, font;
        final Graphics2D g;
        final InsetLayout layout;
        final List<int[]> labels = new ArrayList<>();
        BufferedImage beforeLabels;
        boolean textStarted;
        Canvas(InsetLayout layout, BufferedImage font) {
            this.layout=layout; this.font=font;
            image=new BufferedImage(layout.panelX+layout.panelWidth+layout.margin,
                layout.panelHeight, BufferedImage.TYPE_INT_ARGB);
            g=image.createGraphics();
            g.setColor(new Color(RulerOverlay.BACKGROUND,true));
            g.fillRect(0,0,image.getWidth(),image.getHeight());
            int[] colors={0xff304326,0xff172f2e,0xff456334,0xff0d231c};
            for(int y=0;y<layout.height;y++) for(int x=0;x<layout.width;x++) {
                int sx=layout.sampleX+x/layout.step, sy=layout.sampleY+y;
                image.setRGB(layout.x+x,layout.y+y,colors[(sx/4+sy/90)%colors.length]);
            }
            g.setColor(Color.WHITE);
            g.drawString("SYNTHETIC PIXEL-GRID TEST (not a game capture)",layout.x,20);
        }
        public void fill(int x,int y,int width,int height,int color) {
            require(!textStarted,"A fill after a label would reproduce the 0.2.4 overpainting bug");
            g.setColor(new Color(color,true)); g.fillRect(x,y,width,height);
        }
        public int textWidth(String text) { return text.length()*6; }
        public void text(String text,int x,int y,int scale,int color) {
            if (!textStarted) {
                beforeLabels=new BufferedImage(image.getWidth(),image.getHeight(),BufferedImage.TYPE_INT_ARGB);
                Graphics2D copy=beforeLabels.createGraphics();copy.drawImage(image,0,0,null);copy.dispose();
            }
            textStarted=true;
            if(layout.labelsInside) {
                int band=labels.size()-layout.range;
                require(color==RulerOverlay.BLACK,"Inline label is not black");
                require(y>=layout.barY && y+8*scale<=layout.barY+layout.barHeight,"Inline digit outside bar");
                require(x>=layout.rulerX(band) && x+textWidth(text)*scale<=layout.rulerX(band+1),"Digit escaped its band");
                int magnitude=band<0?-band:band+1;
                require(text.equals(Integer.toString(magnitude)),"Band label sequence incorrect");
                int outer=band<0?layout.rulerX(band):layout.rulerX(band+1);
                require(Math.abs(outer-layout.centerX())==magnitude*layout.step,"Band label no longer identifies its correction edge");
            } else require(y>layout.barY+layout.barHeight,"Fallback digit overlaps colored bands");
            require(x>=layout.panelX && x+textWidth(text)*scale<=layout.panelX+layout.panelWidth,"Digit clipped by panel");
            require(y+9*scale<=layout.y+layout.height,"Digit clipped vertically");
            for(int[] previous:labels) {
                require(previous[0]+previous[2]<=x || x+textWidth(text)*scale<=previous[0]
                    || previous[1]+previous[3]<=y || y+9*scale<=previous[1],"Neighboring digits overlap");
            }
            int offset=labels.size()-layout.range;
            if(layout.compactLabels && offset>=0) offset++;
            if(!layout.labelsInside) require(text.equals(Integer.toString(Math.abs(offset))),"Individual correction number missing");
            if(layout.compactLabels) require(!text.equals("0"),"Zero label returned");
            labels.add(new int[]{x,y,textWidth(text)*scale,9*scale});
            for(int index=0;index<text.length();index++) {
                int ch=text.charAt(index);
                for(int fy=0;fy<8;fy++) for(int fx=0;fx<8;fx++) {
                    if((font.getRGB((ch%16)*8+fx,(ch/16)*8+fy)>>>24)==0) continue;
                    g.setColor(new Color(color,true));
                    g.fillRect(x+(index*6+fx)*scale,y+fy*scale,scale,scale);
                }
            }
        }
    }
    public static void main(String[] args) throws Exception {
        BufferedImage font;
        try(InputStream input=OverlayCheck.class.getResourceAsStream("/assets/minecraft/textures/font/ascii.png")) {
            require(input!=null,"Missing Minecraft font for visual regression");
            font=ImageIO.read(input);
        }
        require(font.getWidth()==128 && font.getHeight()==128,"Unexpected digit atlas");
        int cases=0;
        for(int[] size:new int[][]{{640,480},{1280,720},{1920,1080},{2047,1109},{3840,2160}})
        for(int magnification:new int[]{2,5,12,24,32,64})
        for(int range:new int[]{8,9,12,15,16})
        for(boolean oppositeSides:new boolean[]{false,true}) {
            InsetLayout l=new InsetLayout(size[0],size[1],0,720,650,3,magnification,range,true,32,3,oppositeSides);
            Canvas canvas=new Canvas(l,font);
            int sourceZero=canvas.image.getRGB(l.centerX(),l.y+10);
            RulerOverlay.draw(l,canvas);
            require(canvas.image.getRGB(l.centerX(),l.y+10)==sourceZero,"Center stroke hides source column zero");
            for(int i=-l.range;i<l.range;i++) {
                int expected=(i&1)==0?RulerOverlay.BLUE:RulerOverlay.PINK;
                // No zero-marker exception: all pixels of both central bands must remain colored.
                for(int x=l.rulerX(i);x<l.rulerX(i+1);x++) {
                    for(int y=l.barY;y<l.barY+l.barHeight;y++)
                        require(canvas.beforeLabels.getRGB(x,y)==expected,"Uneven or overwritten colored band height");
                }
            }
            require(canvas.labels.size()==2*l.range+(l.compactLabels?0:1),"Not every correction is numbered");
            require(canvas.image.getRGB(l.centerX()-1,l.barY-1)==RulerOverlay.WHITE,
                "Zero ray moved when its bar overlap was removed");
            if(!oppositeSides && magnification==12 && range==16 && size[0]>=1920)
                require(l.labelRows==2 && l.rulerLabelScale==2,"Default labels should use two readable rows");
            if(!oppositeSides && magnification==12 && range==9 && size[0]>=1920)
                require(l.labelRows==1 && l.rulerLabelScale==2 && canvas.labels.size()==19,
                    "Nine-per-side default must retain all digits in one readable row");
            if(!oppositeSides && range==8 && magnification==24 && size[0]>=1280) {
                require(canvas.labels.size()==17 && l.rulerLabelScale==Math.max(1,l.step/8),"Default ruler digits missing or too small");
            }
            if(!oppositeSides && size[0]==1920 && magnification==12 && range==9 && args.length>0) {
                File output=new File(args[0]); output.getParentFile().mkdirs();
                ImageIO.write(canvas.image,"png",output);
            }
            canvas.g.dispose(); cases++;
        }
        System.out.println("PASS: "+cases+" production overlay drawings, equal bands, readable nonoverlapping digits and fill-before-text order");
    }
    private static void require(boolean value,String message) { if(!value) throw new AssertionError(message); }
}
