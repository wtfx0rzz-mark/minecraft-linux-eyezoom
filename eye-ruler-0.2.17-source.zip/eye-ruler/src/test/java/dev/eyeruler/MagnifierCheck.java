package dev.eyeruler;

/** Checks the normal-scene-to-inset transform, including odd framebuffers. */
public final class MagnifierCheck {
    public static void main(String[] args) {
        int cases = 0;
        for (int[] size : new int[][] {{640,480},{1280,720},{1920,1080},{2047,1109},{3708,2022},{3840,2160}})
        for (int panelWidth : new int[] {160,720,1200})
        for (int scale : new int[] {0,1,3})
        for (int zoom : new int[] {2,7,14,28}) {
            InsetLayout r = new InsetLayout(size[0], size[1], scale, panelWidth,650,3,24,8,true,32,3);
            if (!r.visible) continue;
            MagnifierLayout m = new MagnifierLayout(r, size[0], size[1], zoom);
            require(r.panelX == 0 && m.panelX == r.panelWidth, "Panels must touch at left edge");
            require(m.width == r.width && m.height == r.height && m.y == r.y, "Unequal preview sizes");
            require(m.panelX + r.panelWidth <= size[0]/2 - r.centerSafetyGap, "Main crosshair obscured");
            require(m.copyX >= 0 && m.copyX + m.sourceWidth <= size[0], "X copy out of bounds");
            require(m.copyY >= 0 && m.copyY + m.sourceHeight <= size[1], "Y copy out of bounds");
            require(m.sampleX >= 0 && m.sampleX + m.sampleWidth <= m.sourceWidth, "X sampling out of bounds");
            require(m.sampleY >= 0 && m.sampleY + m.sampleHeight <= m.sourceHeight, "Y sampling out of bounds");
            // Check every row/column against an independently calculated centered crop.
            float u0 = (float)(m.sampleX/m.sourceWidth), u1 = (float)((m.sampleX+m.sampleWidth)/m.sourceWidth);
            float v0 = (float)(1-m.sampleY/m.sourceHeight), v1 = (float)(1-(m.sampleY+m.sampleHeight)/m.sourceHeight);
            for (int x = 0; x < m.width; x++) {
                double source = m.copyX + (u0 + ((double)u1-u0)*(x+0.5)/m.width)*m.sourceWidth;
                near(source, size[0]/2.0 + (x+0.5-m.width/2.0)/zoom, 0.0001);
            }
            for (int y = 0; y < m.height; y++) {
                double source = m.copyY + (1-(v0 + ((double)v1-v0)*(y+0.5)/m.height))*m.sourceHeight;
                near(source, size[1]/2.0 + (y+0.5-m.height/2.0)/zoom, 0.0001);
            }
            double zeroX = m.x + (size[0]/2.0-m.copyX-m.sampleX)*zoom;
            double zeroY = m.y + (size[1]/2.0-m.copyY-m.sampleY)*zoom;
            near(zeroX, m.centerX(), 1e-9);
            near(zeroY, m.centerY(), 1e-9);
            cases++;
        }
        System.out.println("PASS: " + cases + " adjacent-panel layouts, uniform 2x/7x/14x/28x crops and center alignment cases");
    }
    private static void near(double a, double b, double tolerance) {
        require(Math.abs(a-b) <= tolerance, "Source mapping mismatch: " + a + " != " + b);
    }
    private static void require(boolean pass, String message) { if (!pass) throw new AssertionError(message); }
}
