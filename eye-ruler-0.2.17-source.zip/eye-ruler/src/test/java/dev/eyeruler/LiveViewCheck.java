package dev.eyeruler;

/** Verify the shared live texture's crop, guide, texel mapping and optical scale. */
public final class LiveViewCheck {
    public static void main(String[] args) {
        int cases = 0;
        for (int[] size : new int[][] {{640,480},{1280,720},{1920,1080},{2047,1109},{3708,2022},{3840,2160}})
        for (int request : new int[] {256,512,1024,1400,2048})
        for (int range : new int[] {8,9,12,15,16}) {
            InsetLayout r = new InsetLayout(size[0],size[1],0,720,650,3,12,range,true,32,3);
            if (!r.visible) continue;
            LiveViewLayout v = new LiveViewLayout(r,request);
            require((v.sourceWidth & 3)==0 && (v.sourceHeight & 3)==0,"Unaligned source buffer");
            require(2*v.sampleX+r.sampleWidth==v.sourceWidth,"Horizontal zero shifted");
            require(2*v.sampleY+r.height==v.sourceHeight,"Vertical zero shifted");
            near(v.mapX(v.sourceWidth/2.0),v.x+v.width/2.0,1e-9);
            near(v.mapY(v.sourceHeight/2.0),v.y+v.height/2.0,1e-9);
            near(v.viewWidth/v.sourceWidth,v.viewHeight/v.sourceHeight,1e-12);
            require(v.guideLeft>=v.x && v.guideRight<=v.x+v.width
                && v.guideTop>=v.y && v.guideBottom<=v.y+v.height,"Guide outside live view");
            near((v.guideRight-v.guideLeft)/v.displayScale,r.sampleWidth,1e-9);
            near((v.guideBottom-v.guideTop)/v.displayScale,r.height,1e-9);
            v.drawOutline((x0,y0,x1,y1,color) -> {
                require(x0>=v.x && y0>=v.y && x1<=v.x+v.width && y1<=v.y+v.height,"Outline escaped panel");
                require(x1<=v.guideLeft || x0>=v.guideRight || y1<=v.guideTop || y0>=v.guideBottom,
                    "Outline covers measurement sample");
            });
            // Match float UV interpolation and top-left Y conversion in RulerHud.
            float u0=(float)((double)v.sampleX/v.sourceWidth);
            float u1=(float)((double)(v.sampleX+r.sampleWidth)/v.sourceWidth);
            for(int i=-r.range;i<r.range;i++) for(int dx=0;dx<r.step;dx++) {
                double display=r.rulerX(i)+dx+0.5;
                int source=(int)Math.floor((u0+((double)u1-u0)*(display-r.x)/r.width)*v.sourceWidth);
                require(source==v.sourceWidth/2+i,"Colored band differs from sampled source pixel");
            }
            float top=(float)(1-(double)v.sampleY/v.sourceHeight);
            float bottom=(float)(1-(double)(v.sampleY+r.height)/v.sourceHeight);
            for(int row=0;row<r.height;row++) {
                double uv=top+((double)bottom-top)*(row+0.5)/r.height;
                int sampled=v.sourceHeight-1-(int)Math.floor(uv*v.sourceHeight);
                require(sampled==v.sampleY+row,"Rows rescaled or flipped");
            }
            // A larger context render must retain the old tall-resolution focal length.
            for(int virtual:new int[]{8192,16384,32768}) {
                double focal=v.sourceHeight/(2*Math.tan(Math.toRadians(Projection.fov(v.sourceHeight,virtual)/2)));
                double old=r.sourceHeight/(2*Math.tan(Math.toRadians(Projection.fov(r.sourceHeight,virtual)/2)));
                near(focal,old,1e-8);
                for(int i=-16;i<=16;i++) near(Math.atan(i/focal),Math.atan(i/old),1e-12);
            }
            cases++;
        }
        for(int[] size:new int[][]{{1920,1080},{3708,2022}}) {
            InsetLayout old=new InsetLayout(size[0],size[1],0,720,650,3,24,8,true,32,3);
            InsetLayout wide=new InsetLayout(size[0],size[1],0,720,650,3,12,16,true,32,3);
            require(wide.width>=old.width && wide.height==old.height,"Wider view shrank the panel");
            require(wide.sampleWidth>=2*old.sampleWidth,"Default sampling area is not at least twice as wide");
        }
        System.out.println("PASS: "+cases+" live-view crop/outline/UV mappings, signed +/-16 calibration and 2x coverage");
    }
    private static void near(double a,double b,double tolerance) {
        require(Double.isFinite(a) && Math.abs(a-b)<=tolerance,a+" != "+b);
    }
    private static void require(boolean value,String message) { if(!value) throw new AssertionError(message); }
}
