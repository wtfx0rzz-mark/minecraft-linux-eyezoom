package dev.eyeruler;

public final class ZoomCheck {
    public static void main(String[] args) {
        int cases = 0;
        for (int[] screen : new int[][] {{640,480},{1280,720},{1920,1080},{2047,1109},{2560,1440},{3840,2160}})
        for (int divisor : new int[] {1,2,3,4}) for (int requestedStep : new int[] {2,5,12,24,32,64})
        for (int ui : new int[] {0,1,3}) {
            InsetLayout l = new InsetLayout(screen[0],screen[1],ui,720,650,divisor,requestedStep,8,true,32,3);
            if (!l.visible) continue;
            require(l.range==8 && l.width==l.sampleWidth*l.step && l.sampleWidth>=16,
                "Preview no longer uses whole calibrated columns");
            require(l.stripX==l.x && l.stripWidth==l.width && l.stripY==l.y && l.stripHeight==l.height,
                "Preview does not fill measurement window");
            require(l.panelY==0 && l.panelHeight==screen[1], "Panel does not use full height");
            require(l.panelX==0 && l.panelX+2*l.panelWidth <= screen[0]/2-l.centerSafetyGap, "Main center crowded");
            require(l.divisor==1 && l.sourceWidth-l.sampleWidth<4 && l.sourceHeight-l.height<4,
                "Oversized render target or vertical downsampling restored");
            require(2*l.sampleX+l.sampleWidth==l.sourceWidth && 2*l.sampleY+l.height==l.sourceHeight,
                "Crop not centered on the optical axis");
            float u0 = (float)l.sampleX/l.sourceWidth;
            float u1 = (float)(l.sampleX+l.sampleWidth)/l.sourceWidth;
            for (int offset=-l.sampleWidth/2; offset<l.sampleWidth/2; offset++) for (int pixel=0; pixel<l.step; pixel++) {
                int displayX=l.centerX()+offset*l.step+pixel;
                double ratio=(displayX+0.5-l.x)/l.width;
                int sourceColumn=(int)Math.floor((u0+((double)u1-u0)*ratio)*l.sourceWidth);
                require(sourceColumn==l.sourceWidth/2+offset, "Ruler band differs from preview source column");
            }
            require(l.rulerX(-8)>=l.x && l.rulerX(8)<=l.x+l.width, "Ruler outside preview");
            // Use the same top-left-to-OpenGL UV convention as the actual HUD.
            float v0=1-(float)l.sampleY/l.sourceHeight;
            float v1=1-(float)(l.sampleY+l.height)/l.sourceHeight;
            for (int row=0; row<l.height; row++) {
                double v=v0+((double)v1-v0)*(row+0.5)/l.height;
                int sampledRow=l.sourceHeight-1-(int)Math.floor(v*l.sourceHeight);
                require(sampledRow==l.sampleY+row, "Y must be upright and exactly 1:1, not squashed");
            }
            double focal=l.sourceHeight/(2*Math.tan(Math.toRadians(Projection.fov(l.sourceHeight,16384)/2)));
            near(focal,16384/(2*Math.tan(Math.toRadians(15))),1e-8);
            cases++;
        }
        require(ZoomGeometry.normalize(Double.NaN)==12, "Invalid magnification fallback wrong");
        System.out.println("PASS: "+cases+" whole-preview X mappings, 1:1 upright Y crops, minimal buffers and calibration cases");
    }
    private static void near(double a,double b,double e) { require(Math.abs(a-b)<=e,a+" != "+b); }
    private static void require(boolean b,String message) { if(!b) throw new AssertionError(message); }
}
