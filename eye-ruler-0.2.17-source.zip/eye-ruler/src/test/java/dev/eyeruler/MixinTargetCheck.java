package dev.eyeruler;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

/** Check the pinned injection against actual mapped 1.16.1 bytecode, without launching the client. */
public final class MixinTargetCheck {
    public static void main(String[] args) throws Exception {
        ClassNode game=read("net.minecraft.client.render.GameRenderer");
        int count=0;
        for(MethodNode method:game.methods) if(method.name.equals("renderWorld")) {
            String previousField="",lastField="";
            for(AbstractInsnNode instruction:method.instructions) {
                if(instruction instanceof FieldInsnNode) {
                    previousField=lastField; lastField=((FieldInsnNode)instruction).name;
                }
                if(instruction instanceof MethodInsnNode) {
                    MethodInsnNode call=(MethodInsnNode)instruction;
                    if(call.owner.equals("net/minecraft/util/math/MathHelper") && call.name.equals("lerp") && call.desc.equals("(FFF)F")) {
                        require(count++==0,"Another float lerp was added to renderWorld");
                        require(lastField.equals("nextNauseaStrength"),"Ordinal 0 is no longer nausea interpolation");
                        // lastNauseaStrength is followed by two client/player field reads.
                        boolean foundPrevious=false;
                        AbstractInsnNode cursor=instruction.getPrevious();
                        for(int i=0;cursor!=null && i<12;i++,cursor=cursor.getPrevious()) {
                            if(cursor instanceof FieldInsnNode && ((FieldInsnNode)cursor).name.equals("lastNauseaStrength")) foundPrevious=true;
                        }
                        require(foundPrevious,"Missing previous nausea input");
                    }
                }
            }
        }
        require(count==1,"Expected exactly one nausea interpolation in 1.16.1 renderWorld");
        boolean pinned=false;
        for(MethodNode method:read("dev.eyeruler.mixin.GameRendererMixin").methods) {
            if(!method.name.equals("eyeRulerPortalDistortion") || method.visibleAnnotations==null) continue;
            for(AnnotationNode annotation:method.visibleAnnotations) if(annotation.desc.endsWith("/Redirect;")) {
                AnnotationNode at=(AnnotationNode)value(annotation,"at");
                pinned=Integer.valueOf(0).equals(value(at,"ordinal"))
                    && Integer.valueOf(1).equals(value(annotation,"require"))
                    && Integer.valueOf(1).equals(value(annotation,"allow"));
            }
        }
        require(pinned,"Nausea redirect is not pinned to exactly ordinal 0");
        System.out.println("PASS: exact ordinal-0 nausea lerp target and required single mixin injection");
    }
    private static ClassNode read(String name) throws Exception {
        ClassNode node=new ClassNode(); new ClassReader(name).accept(node,0); return node;
    }
    private static Object value(AnnotationNode annotation,String key) {
        for(int i=0;i<annotation.values.size();i+=2) if(key.equals(annotation.values.get(i))) return annotation.values.get(i+1);
        return null;
    }
    private static void require(boolean value,String message) { if(!value) throw new AssertionError(message); }
}
