package dev.eyeruler;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/** Verify that enlargement preserves every signed correction and the original view transforms. */
public final class MeasurementStripCheck {
    public static void main(String[] args) throws Exception {
        int cases=0, enlarged=0;
        for(int[] size:new int[][]{{640,480},{1280,720},{1920,1080},{2047,1109},{3708,2022},{3840,2160}})
        for(int range:new int[]{8,9,12,16})
        for(int magnification:new int[]{5,12,24,64})
        for(int sourceWidth:new int[]{256,1024,2048}) {
            InsetLayout r=layout(size[0],size[1],magnification,range);
            LiveViewLayout v=new LiveViewLayout(r,sourceWidth);
            MeasurementStripLayout d=new MeasurementStripLayout(r,v);
            if(!d.visible) { require(d.mainHeight==r.height,"Fallback cropped the original view"); cases++; continue; }
            require(d.step>r.step && d.step<=2*r.step,"Detail is not an enlargement");
            require(d.x>=r.x && d.x+d.width<=r.x+r.width,"Detail escaped panel");
            require(d.y+d.imageHeight<r.y+r.height,"Detail escaped vertically");
            require(r.labelY+(10*r.labelRows+2)*r.rulerLabelScale<r.y+d.mainHeight,"Original ruler/labels hidden");
            require(r.y+d.mainHeight<d.panelTop,"No gap before detail title");
            require(d.sourceX*2+d.sourceWidth==v.sourceWidth && d.sourceY*2+d.sourceHeight==v.sourceHeight,
                "Detail crop lost its centered integer ray");
            require(d.x+d.width/2==r.centerX(),"Detail zero differs from original zero");
            // The source buffer/projection and right transform remain exactly the pre-detail layout.
            near(v.displayScale,Math.min((double)r.width/v.sourceWidth,(double)r.height/v.sourceHeight));
            near(v.mapY(v.sourceHeight/2.0),r.centerY());
            // Simulate the same float UVs and nearest sampling as the production HUD, every band pixel.
            float u0=(float)((double)d.sourceX/v.sourceWidth);
            float u1=(float)((double)(d.sourceX+d.sourceWidth)/v.sourceWidth);
            for(int i=-range;i<range;i++) for(int pixel=0;pixel<d.step;pixel++) {
                double x=d.overlay.rulerX(i)+pixel+0.5;
                int sx=(int)Math.floor((u0+(u1-(double)u0)*(x-d.x)/d.width)*v.sourceWidth);
                require(sx==v.sourceWidth/2+i,"Enlarged band samples wrong source column at "+i);
            }
            float top=(float)(1-(double)d.sourceY/v.sourceHeight);
            float bottom=(float)(1-(double)(d.sourceY+d.sourceHeight)/v.sourceHeight);
            for(int row=0;row<d.imageHeight;row++) {
                double uv=top+(bottom-(double)top)*(row+0.5)/d.imageHeight;
                int sy=v.sourceHeight-1-(int)Math.floor(uv*v.sourceHeight);
                require(sy==d.sourceY+row/d.verticalScale,"Detail image flipped or rows mismatched");
            }
            // Original view remains 1:1 vertically, using the same top source row (no recentering).
            float mainTop=(float)(1-(double)v.sampleY/v.sourceHeight);
            float mainBottom=(float)(1-(double)(v.sampleY+d.mainHeight)/v.sourceHeight);
            for(int row=0;row<d.mainHeight;row++) {
                int sy=v.sourceHeight-1-(int)Math.floor((mainTop+(mainBottom-(double)mainTop)
                    *(row+0.5)/d.mainHeight)*v.sourceHeight);
                require(sy==v.sampleY+row,"Original eye scale or position changed");
            }
            double visibleBottom=v.mapY(v.sampleY+d.mainHeight);
            v.drawOutline((x0,y0,x1,y1,color)-> {
                require(x1<=v.guideLeft || x0>=v.guideRight || y1<=v.guideTop || y0>=visibleBottom,
                    "Guide covers visible sample interior");
            },d.mainHeight);
            TestCanvas canvas=new TestCanvas(null,null,d.overlay);
            RulerOverlay.draw(d.overlay,canvas);
            require(canvas.labels.size()==2*range+1,"Detail missing signed range labels");
            enlarged++; cases++;
        }
        if(args.length>0) {
            BufferedImage font;
            try(InputStream in=MeasurementStripCheck.class.getResourceAsStream("/assets/minecraft/textures/font/ascii.png")) {
                require(in!=null,"Missing digit font"); font=ImageIO.read(in);
            }
            for(int[] size:new int[][]{{1920,1080},{3708,2022}}) {
                InsetLayout r=layout(size[0],size[1],12,9);
                LiveViewLayout v=new LiveViewLayout(r,1024);
                MeasurementStripLayout d=new MeasurementStripLayout(r,v);
                require(d.visible && d.overlay.labelRows==1,"Desktop default not readable");
                require(d.overlay.rulerLabelScale>r.rulerLabelScale,"Default digits not enlarged");
                BufferedImage image=render(r,v,d,font);
                // Inspect every colored pixel from the same painter used in game.
                for(int i=-9;i<9;i++) for(int x=d.overlay.rulerX(i);x<d.overlay.rulerX(i+1);x++)
                for(int y=d.overlay.barY;y<d.overlay.barY+d.overlay.barHeight;y++)
                    require(image.getRGB(x,y)==((i&1)==0?RulerOverlay.BLUE:RulerOverlay.PINK),"Uneven detail band");
                File file=new File(args[0],"live-detail-"+size[0]+".png"); file.getParentFile().mkdirs();
                ImageIO.write(image,"png",file);
                System.out.println(size[0]+"x"+size[1]+": main "+r.step+" px/step, detail "+d.step
                    +" px/step, font "+r.rulerLabelScale+" -> "+d.overlay.rulerLabelScale
                    +", main visible rows "+d.mainHeight+", detail "+d.sourceWidth+"x"+d.sourceHeight);
            }
        }
        System.out.println("PASS: "+cases+" detail layouts ("+enlarged+" enlarged), signed pixel UVs, zero, unchanged scales, guide and labels");
    }
    private static InsetLayout layout(int w,int h,int mag,int range) {
        return new InsetLayout(w,h,0,720,650,3,mag,range,true,32,3);
    }
    private static BufferedImage render(InsetLayout r,LiveViewLayout v,MeasurementStripLayout d,BufferedImage font) {
        BufferedImage image=new BufferedImage(2*r.panelWidth,r.panelHeight,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g=image.createGraphics();
        g.setColor(new Color(RulerOverlay.BACKGROUND,true)); g.fillRect(0,0,image.getWidth(),image.getHeight());
        BufferedImage source=new BufferedImage(v.sourceWidth,v.sourceHeight,BufferedImage.TYPE_INT_RGB);
        int[] colors={0xff243d30,0xff426031,0xff365126,0xff09251e};
        for(int y=0;y<source.getHeight();y++) for(int x=0;x<source.getWidth();x++) {
            int dx=x-source.getWidth()/2,dy=y-source.getHeight()/2;
            int color=Math.abs(dx-3)<180 && Math.abs(dy)<220?colors[Math.floorMod(dx/35+dy/55,4)]:0xff85b6ea;
            if(dx>=3 && dx<36 && Math.abs(dy)<110) color=0xff071510;
            source.setRGB(x,y,color);
        }
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        g.drawImage(source,r.x,r.y,r.x+r.width,r.y+d.mainHeight,v.sampleX,v.sampleY,
            v.sampleX+r.sampleWidth,v.sampleY+d.mainHeight,null);
        RulerOverlay.Geometry original=new RulerOverlay.Geometry(r.scale,r.y,d.mainHeight,r.centerX(),r.panelX,r.panelWidth,
            r.range,r.step,r.barY,r.barHeight,r.rulerLabelScale,r.labelY,r.labelRows);
        RulerOverlay.draw(original,new TestCanvas(image,font,original));
        g.drawImage(source,d.x,d.y,d.x+d.width,d.y+d.imageHeight,d.sourceX,d.sourceY,
            d.sourceX+d.sourceWidth,d.sourceY+d.sourceHeight,null);
        RulerOverlay.draw(d.overlay,new TestCanvas(image,font,d.overlay));
        g.drawImage(source,(int)v.viewX,(int)v.viewY,(int)(v.viewX+v.viewWidth),(int)(v.viewY+v.viewHeight),
            0,0,v.sourceWidth,v.sourceHeight,null);
        v.drawOutline((x0,y0,x1,y1,color)-> {g.setColor(new Color(color,true));
            g.fill(new java.awt.geom.Rectangle2D.Double(x0,y0,x1-x0,y1-y0));},d.mainHeight);
        g.setColor(Color.WHITE); g.setFont(new java.awt.Font("SansSerif",java.awt.Font.PLAIN,12*r.scale));
        g.drawString("SYNTHETIC LIVE-PIXEL TEST",r.x,18*r.scale);
        g.drawString("LIVE DETAIL | "+d.step+" px / step",r.x,d.panelTop+9*r.scale);
        g.dispose(); return image;
    }
    private static final class TestCanvas implements RulerOverlay.Canvas {
        final BufferedImage image,font; final RulerOverlay.Geometry l;
        final List<int[]> labels=new ArrayList<>(); boolean textStarted;
        TestCanvas(BufferedImage image,BufferedImage font,RulerOverlay.Geometry layout) {
            this.image=image;this.font=font;this.l=layout;
        }
        public void fill(int x,int y,int w,int h,int color) {
            require(!textStarted,"Fills overwrite numbers"); require(w>=0 && h>=0,"Negative rectangle");
            if(image!=null) { Graphics2D g=image.createGraphics();g.setColor(new Color(color,true));g.fillRect(x,y,w,h);g.dispose(); }
        }
        public int textWidth(String text) {return text.length()*6;}
        public void text(String text,int x,int y,int scale,int color) {
            textStarted=true; int w=textWidth(text)*scale,h=9*scale;
            require(x>=l.panelX && x+w<=l.panelX+l.panelWidth && y+h<=l.y+l.height,"Label clipped");
            require(text.equals(Integer.toString(Math.abs(labels.size()-l.range))),"Label sequence wrong");
            for(int[] other:labels) require(x+w<=other[0] || other[0]+other[2]<=x || y+h<=other[1] || other[1]+other[3]<=y,"Label overlap");
            labels.add(new int[]{x,y,w,h});
            if(image==null)return;
            Graphics2D g=image.createGraphics();g.setColor(new Color(color,true));
            for(int i=0;i<text.length();i++) for(int fy=0;fy<8;fy++) for(int fx=0;fx<8;fx++) {
                int ch=text.charAt(i);
                if((font.getRGB(ch%16*8+fx,ch/16*8+fy)>>>24)!=0)g.fillRect(x+(i*6+fx)*scale,y+fy*scale,scale,scale);
            }
            g.dispose();
        }
    }
    private static void require(boolean v,String message) {if(!v)throw new AssertionError(message);}
    private static void near(double a,double b) {require(Math.abs(a-b)<1e-9,a+" != "+b);}
}
